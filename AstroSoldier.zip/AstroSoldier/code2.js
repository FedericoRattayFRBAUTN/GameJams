gdjs.level0Code = {};
gdjs.level0Code.GDbarrelObjects3_1final = [];

gdjs.level0Code.GDbarrelObjects4_1final = [];

gdjs.level0Code.GDbulletObjects3_1final = [];

gdjs.level0Code.GDbulletObjects8_1final = [];

gdjs.level0Code.GDcover_9595boxObjects3_1final = [];

gdjs.level0Code.GDcover_9595boxObjects4_1final = [];

gdjs.level0Code.GDenemyObjects4_1final = [];

gdjs.level0Code.GDenemy_9595meleeObjects4_1final = [];

gdjs.level0Code.GDgrenadeObjects4_1final = [];

gdjs.level0Code.GDmelee_9595weaponObjects3_1final = [];

gdjs.level0Code.GDplayerObjects2_1final = [];

gdjs.level0Code.GDsandbagObjects3_1final = [];

gdjs.level0Code.GDsandbagObjects4_1final = [];

gdjs.level0Code.GDwallObjects3_1final = [];

gdjs.level0Code.GDwallObjects4_1final = [];

gdjs.level0Code.forEachCount0_5 = 0;

gdjs.level0Code.forEachCount1_5 = 0;

gdjs.level0Code.forEachIndex2 = 0;

gdjs.level0Code.forEachIndex3 = 0;

gdjs.level0Code.forEachIndex4 = 0;

gdjs.level0Code.forEachIndex5 = 0;

gdjs.level0Code.forEachIndex6 = 0;

gdjs.level0Code.forEachIndex7 = 0;

gdjs.level0Code.forEachIndex8 = 0;

gdjs.level0Code.forEachObjects2 = [];

gdjs.level0Code.forEachObjects3 = [];

gdjs.level0Code.forEachObjects4 = [];

gdjs.level0Code.forEachObjects5 = [];

gdjs.level0Code.forEachObjects6 = [];

gdjs.level0Code.forEachObjects7 = [];

gdjs.level0Code.forEachObjects8 = [];

gdjs.level0Code.forEachTemporary2 = null;

gdjs.level0Code.forEachTemporary3 = null;

gdjs.level0Code.forEachTemporary4 = null;

gdjs.level0Code.forEachTemporary5 = null;

gdjs.level0Code.forEachTemporary6 = null;

gdjs.level0Code.forEachTemporary7 = null;

gdjs.level0Code.forEachTemporary8 = null;

gdjs.level0Code.forEachTotalCount2 = 0;

gdjs.level0Code.forEachTotalCount3 = 0;

gdjs.level0Code.forEachTotalCount4 = 0;

gdjs.level0Code.forEachTotalCount5 = 0;

gdjs.level0Code.forEachTotalCount6 = 0;

gdjs.level0Code.forEachTotalCount7 = 0;

gdjs.level0Code.forEachTotalCount8 = 0;

gdjs.level0Code.GDplayerObjects1= [];
gdjs.level0Code.GDplayerObjects2= [];
gdjs.level0Code.GDplayerObjects3= [];
gdjs.level0Code.GDplayerObjects4= [];
gdjs.level0Code.GDplayerObjects5= [];
gdjs.level0Code.GDplayerObjects6= [];
gdjs.level0Code.GDplayerObjects7= [];
gdjs.level0Code.GDplayerObjects8= [];
gdjs.level0Code.GDplayerObjects9= [];
gdjs.level0Code.GDfloor0Objects1= [];
gdjs.level0Code.GDfloor0Objects2= [];
gdjs.level0Code.GDfloor0Objects3= [];
gdjs.level0Code.GDfloor0Objects4= [];
gdjs.level0Code.GDfloor0Objects5= [];
gdjs.level0Code.GDfloor0Objects6= [];
gdjs.level0Code.GDfloor0Objects7= [];
gdjs.level0Code.GDfloor0Objects8= [];
gdjs.level0Code.GDfloor0Objects9= [];
gdjs.level0Code.GDgunObjects1= [];
gdjs.level0Code.GDgunObjects2= [];
gdjs.level0Code.GDgunObjects3= [];
gdjs.level0Code.GDgunObjects4= [];
gdjs.level0Code.GDgunObjects5= [];
gdjs.level0Code.GDgunObjects6= [];
gdjs.level0Code.GDgunObjects7= [];
gdjs.level0Code.GDgunObjects8= [];
gdjs.level0Code.GDgunObjects9= [];
gdjs.level0Code.GDdebugObjects1= [];
gdjs.level0Code.GDdebugObjects2= [];
gdjs.level0Code.GDdebugObjects3= [];
gdjs.level0Code.GDdebugObjects4= [];
gdjs.level0Code.GDdebugObjects5= [];
gdjs.level0Code.GDdebugObjects6= [];
gdjs.level0Code.GDdebugObjects7= [];
gdjs.level0Code.GDdebugObjects8= [];
gdjs.level0Code.GDdebugObjects9= [];
gdjs.level0Code.GDbulletObjects1= [];
gdjs.level0Code.GDbulletObjects2= [];
gdjs.level0Code.GDbulletObjects3= [];
gdjs.level0Code.GDbulletObjects4= [];
gdjs.level0Code.GDbulletObjects5= [];
gdjs.level0Code.GDbulletObjects6= [];
gdjs.level0Code.GDbulletObjects7= [];
gdjs.level0Code.GDbulletObjects8= [];
gdjs.level0Code.GDbulletObjects9= [];
gdjs.level0Code.GDbarrelObjects1= [];
gdjs.level0Code.GDbarrelObjects2= [];
gdjs.level0Code.GDbarrelObjects3= [];
gdjs.level0Code.GDbarrelObjects4= [];
gdjs.level0Code.GDbarrelObjects5= [];
gdjs.level0Code.GDbarrelObjects6= [];
gdjs.level0Code.GDbarrelObjects7= [];
gdjs.level0Code.GDbarrelObjects8= [];
gdjs.level0Code.GDbarrelObjects9= [];
gdjs.level0Code.GDcover_9595boxObjects1= [];
gdjs.level0Code.GDcover_9595boxObjects2= [];
gdjs.level0Code.GDcover_9595boxObjects3= [];
gdjs.level0Code.GDcover_9595boxObjects4= [];
gdjs.level0Code.GDcover_9595boxObjects5= [];
gdjs.level0Code.GDcover_9595boxObjects6= [];
gdjs.level0Code.GDcover_9595boxObjects7= [];
gdjs.level0Code.GDcover_9595boxObjects8= [];
gdjs.level0Code.GDcover_9595boxObjects9= [];
gdjs.level0Code.GDsandbagObjects1= [];
gdjs.level0Code.GDsandbagObjects2= [];
gdjs.level0Code.GDsandbagObjects3= [];
gdjs.level0Code.GDsandbagObjects4= [];
gdjs.level0Code.GDsandbagObjects5= [];
gdjs.level0Code.GDsandbagObjects6= [];
gdjs.level0Code.GDsandbagObjects7= [];
gdjs.level0Code.GDsandbagObjects8= [];
gdjs.level0Code.GDsandbagObjects9= [];
gdjs.level0Code.GDenemyObjects1= [];
gdjs.level0Code.GDenemyObjects2= [];
gdjs.level0Code.GDenemyObjects3= [];
gdjs.level0Code.GDenemyObjects4= [];
gdjs.level0Code.GDenemyObjects5= [];
gdjs.level0Code.GDenemyObjects6= [];
gdjs.level0Code.GDenemyObjects7= [];
gdjs.level0Code.GDenemyObjects8= [];
gdjs.level0Code.GDenemyObjects9= [];
gdjs.level0Code.GDenemy_9595meleeObjects1= [];
gdjs.level0Code.GDenemy_9595meleeObjects2= [];
gdjs.level0Code.GDenemy_9595meleeObjects3= [];
gdjs.level0Code.GDenemy_9595meleeObjects4= [];
gdjs.level0Code.GDenemy_9595meleeObjects5= [];
gdjs.level0Code.GDenemy_9595meleeObjects6= [];
gdjs.level0Code.GDenemy_9595meleeObjects7= [];
gdjs.level0Code.GDenemy_9595meleeObjects8= [];
gdjs.level0Code.GDenemy_9595meleeObjects9= [];
gdjs.level0Code.GDhealth_9595barObjects1= [];
gdjs.level0Code.GDhealth_9595barObjects2= [];
gdjs.level0Code.GDhealth_9595barObjects3= [];
gdjs.level0Code.GDhealth_9595barObjects4= [];
gdjs.level0Code.GDhealth_9595barObjects5= [];
gdjs.level0Code.GDhealth_9595barObjects6= [];
gdjs.level0Code.GDhealth_9595barObjects7= [];
gdjs.level0Code.GDhealth_9595barObjects8= [];
gdjs.level0Code.GDhealth_9595barObjects9= [];
gdjs.level0Code.GDhealth_9595kitObjects1= [];
gdjs.level0Code.GDhealth_9595kitObjects2= [];
gdjs.level0Code.GDhealth_9595kitObjects3= [];
gdjs.level0Code.GDhealth_9595kitObjects4= [];
gdjs.level0Code.GDhealth_9595kitObjects5= [];
gdjs.level0Code.GDhealth_9595kitObjects6= [];
gdjs.level0Code.GDhealth_9595kitObjects7= [];
gdjs.level0Code.GDhealth_9595kitObjects8= [];
gdjs.level0Code.GDhealth_9595kitObjects9= [];
gdjs.level0Code.GDmelee_9595weaponObjects1= [];
gdjs.level0Code.GDmelee_9595weaponObjects2= [];
gdjs.level0Code.GDmelee_9595weaponObjects3= [];
gdjs.level0Code.GDmelee_9595weaponObjects4= [];
gdjs.level0Code.GDmelee_9595weaponObjects5= [];
gdjs.level0Code.GDmelee_9595weaponObjects6= [];
gdjs.level0Code.GDmelee_9595weaponObjects7= [];
gdjs.level0Code.GDmelee_9595weaponObjects8= [];
gdjs.level0Code.GDmelee_9595weaponObjects9= [];
gdjs.level0Code.GDbloodObjects1= [];
gdjs.level0Code.GDbloodObjects2= [];
gdjs.level0Code.GDbloodObjects3= [];
gdjs.level0Code.GDbloodObjects4= [];
gdjs.level0Code.GDbloodObjects5= [];
gdjs.level0Code.GDbloodObjects6= [];
gdjs.level0Code.GDbloodObjects7= [];
gdjs.level0Code.GDbloodObjects8= [];
gdjs.level0Code.GDbloodObjects9= [];
gdjs.level0Code.GDwaves_9595debugObjects1= [];
gdjs.level0Code.GDwaves_9595debugObjects2= [];
gdjs.level0Code.GDwaves_9595debugObjects3= [];
gdjs.level0Code.GDwaves_9595debugObjects4= [];
gdjs.level0Code.GDwaves_9595debugObjects5= [];
gdjs.level0Code.GDwaves_9595debugObjects6= [];
gdjs.level0Code.GDwaves_9595debugObjects7= [];
gdjs.level0Code.GDwaves_9595debugObjects8= [];
gdjs.level0Code.GDwaves_9595debugObjects9= [];
gdjs.level0Code.GDenemy_9595spawnerObjects1= [];
gdjs.level0Code.GDenemy_9595spawnerObjects2= [];
gdjs.level0Code.GDenemy_9595spawnerObjects3= [];
gdjs.level0Code.GDenemy_9595spawnerObjects4= [];
gdjs.level0Code.GDenemy_9595spawnerObjects5= [];
gdjs.level0Code.GDenemy_9595spawnerObjects6= [];
gdjs.level0Code.GDenemy_9595spawnerObjects7= [];
gdjs.level0Code.GDenemy_9595spawnerObjects8= [];
gdjs.level0Code.GDenemy_9595spawnerObjects9= [];
gdjs.level0Code.GDwave_9595timerObjects1= [];
gdjs.level0Code.GDwave_9595timerObjects2= [];
gdjs.level0Code.GDwave_9595timerObjects3= [];
gdjs.level0Code.GDwave_9595timerObjects4= [];
gdjs.level0Code.GDwave_9595timerObjects5= [];
gdjs.level0Code.GDwave_9595timerObjects6= [];
gdjs.level0Code.GDwave_9595timerObjects7= [];
gdjs.level0Code.GDwave_9595timerObjects8= [];
gdjs.level0Code.GDwave_9595timerObjects9= [];
gdjs.level0Code.GDHUDObjects1= [];
gdjs.level0Code.GDHUDObjects2= [];
gdjs.level0Code.GDHUDObjects3= [];
gdjs.level0Code.GDHUDObjects4= [];
gdjs.level0Code.GDHUDObjects5= [];
gdjs.level0Code.GDHUDObjects6= [];
gdjs.level0Code.GDHUDObjects7= [];
gdjs.level0Code.GDHUDObjects8= [];
gdjs.level0Code.GDHUDObjects9= [];
gdjs.level0Code.GDarmorObjects1= [];
gdjs.level0Code.GDarmorObjects2= [];
gdjs.level0Code.GDarmorObjects3= [];
gdjs.level0Code.GDarmorObjects4= [];
gdjs.level0Code.GDarmorObjects5= [];
gdjs.level0Code.GDarmorObjects6= [];
gdjs.level0Code.GDarmorObjects7= [];
gdjs.level0Code.GDarmorObjects8= [];
gdjs.level0Code.GDarmorObjects9= [];
gdjs.level0Code.GDgrenadesObjects1= [];
gdjs.level0Code.GDgrenadesObjects2= [];
gdjs.level0Code.GDgrenadesObjects3= [];
gdjs.level0Code.GDgrenadesObjects4= [];
gdjs.level0Code.GDgrenadesObjects5= [];
gdjs.level0Code.GDgrenadesObjects6= [];
gdjs.level0Code.GDgrenadesObjects7= [];
gdjs.level0Code.GDgrenadesObjects8= [];
gdjs.level0Code.GDgrenadesObjects9= [];
gdjs.level0Code.GDmedkitsObjects1= [];
gdjs.level0Code.GDmedkitsObjects2= [];
gdjs.level0Code.GDmedkitsObjects3= [];
gdjs.level0Code.GDmedkitsObjects4= [];
gdjs.level0Code.GDmedkitsObjects5= [];
gdjs.level0Code.GDmedkitsObjects6= [];
gdjs.level0Code.GDmedkitsObjects7= [];
gdjs.level0Code.GDmedkitsObjects8= [];
gdjs.level0Code.GDmedkitsObjects9= [];
gdjs.level0Code.GDHUD_9595nadesObjects1= [];
gdjs.level0Code.GDHUD_9595nadesObjects2= [];
gdjs.level0Code.GDHUD_9595nadesObjects3= [];
gdjs.level0Code.GDHUD_9595nadesObjects4= [];
gdjs.level0Code.GDHUD_9595nadesObjects5= [];
gdjs.level0Code.GDHUD_9595nadesObjects6= [];
gdjs.level0Code.GDHUD_9595nadesObjects7= [];
gdjs.level0Code.GDHUD_9595nadesObjects8= [];
gdjs.level0Code.GDHUD_9595nadesObjects9= [];
gdjs.level0Code.GDfloor1Objects1= [];
gdjs.level0Code.GDfloor1Objects2= [];
gdjs.level0Code.GDfloor1Objects3= [];
gdjs.level0Code.GDfloor1Objects4= [];
gdjs.level0Code.GDfloor1Objects5= [];
gdjs.level0Code.GDfloor1Objects6= [];
gdjs.level0Code.GDfloor1Objects7= [];
gdjs.level0Code.GDfloor1Objects8= [];
gdjs.level0Code.GDfloor1Objects9= [];
gdjs.level0Code.GDdeath_9595messageObjects1= [];
gdjs.level0Code.GDdeath_9595messageObjects2= [];
gdjs.level0Code.GDdeath_9595messageObjects3= [];
gdjs.level0Code.GDdeath_9595messageObjects4= [];
gdjs.level0Code.GDdeath_9595messageObjects5= [];
gdjs.level0Code.GDdeath_9595messageObjects6= [];
gdjs.level0Code.GDdeath_9595messageObjects7= [];
gdjs.level0Code.GDdeath_9595messageObjects8= [];
gdjs.level0Code.GDdeath_9595messageObjects9= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects6= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects7= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects8= [];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects9= [];
gdjs.level0Code.GDupgrade_9595menuObjects1= [];
gdjs.level0Code.GDupgrade_9595menuObjects2= [];
gdjs.level0Code.GDupgrade_9595menuObjects3= [];
gdjs.level0Code.GDupgrade_9595menuObjects4= [];
gdjs.level0Code.GDupgrade_9595menuObjects5= [];
gdjs.level0Code.GDupgrade_9595menuObjects6= [];
gdjs.level0Code.GDupgrade_9595menuObjects7= [];
gdjs.level0Code.GDupgrade_9595menuObjects8= [];
gdjs.level0Code.GDupgrade_9595menuObjects9= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects1= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects2= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects4= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects5= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects6= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects7= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects8= [];
gdjs.level0Code.GDupgrade_9595menu_9595textObjects9= [];
gdjs.level0Code.GDshadowObjects1= [];
gdjs.level0Code.GDshadowObjects2= [];
gdjs.level0Code.GDshadowObjects3= [];
gdjs.level0Code.GDshadowObjects4= [];
gdjs.level0Code.GDshadowObjects5= [];
gdjs.level0Code.GDshadowObjects6= [];
gdjs.level0Code.GDshadowObjects7= [];
gdjs.level0Code.GDshadowObjects8= [];
gdjs.level0Code.GDshadowObjects9= [];
gdjs.level0Code.GDexit_9595textObjects1= [];
gdjs.level0Code.GDexit_9595textObjects2= [];
gdjs.level0Code.GDexit_9595textObjects3= [];
gdjs.level0Code.GDexit_9595textObjects4= [];
gdjs.level0Code.GDexit_9595textObjects5= [];
gdjs.level0Code.GDexit_9595textObjects6= [];
gdjs.level0Code.GDexit_9595textObjects7= [];
gdjs.level0Code.GDexit_9595textObjects8= [];
gdjs.level0Code.GDexit_9595textObjects9= [];
gdjs.level0Code.GDrageObjects1= [];
gdjs.level0Code.GDrageObjects2= [];
gdjs.level0Code.GDrageObjects3= [];
gdjs.level0Code.GDrageObjects4= [];
gdjs.level0Code.GDrageObjects5= [];
gdjs.level0Code.GDrageObjects6= [];
gdjs.level0Code.GDrageObjects7= [];
gdjs.level0Code.GDrageObjects8= [];
gdjs.level0Code.GDrageObjects9= [];
gdjs.level0Code.GDwallObjects1= [];
gdjs.level0Code.GDwallObjects2= [];
gdjs.level0Code.GDwallObjects3= [];
gdjs.level0Code.GDwallObjects4= [];
gdjs.level0Code.GDwallObjects5= [];
gdjs.level0Code.GDwallObjects6= [];
gdjs.level0Code.GDwallObjects7= [];
gdjs.level0Code.GDwallObjects8= [];
gdjs.level0Code.GDwallObjects9= [];
gdjs.level0Code.GDlevel_9595designObjects1= [];
gdjs.level0Code.GDlevel_9595designObjects2= [];
gdjs.level0Code.GDlevel_9595designObjects3= [];
gdjs.level0Code.GDlevel_9595designObjects4= [];
gdjs.level0Code.GDlevel_9595designObjects5= [];
gdjs.level0Code.GDlevel_9595designObjects6= [];
gdjs.level0Code.GDlevel_9595designObjects7= [];
gdjs.level0Code.GDlevel_9595designObjects8= [];
gdjs.level0Code.GDlevel_9595designObjects9= [];
gdjs.level0Code.GDexplosionObjects1= [];
gdjs.level0Code.GDexplosionObjects2= [];
gdjs.level0Code.GDexplosionObjects3= [];
gdjs.level0Code.GDexplosionObjects4= [];
gdjs.level0Code.GDexplosionObjects5= [];
gdjs.level0Code.GDexplosionObjects6= [];
gdjs.level0Code.GDexplosionObjects7= [];
gdjs.level0Code.GDexplosionObjects8= [];
gdjs.level0Code.GDexplosionObjects9= [];
gdjs.level0Code.GDgrenadeObjects1= [];
gdjs.level0Code.GDgrenadeObjects2= [];
gdjs.level0Code.GDgrenadeObjects3= [];
gdjs.level0Code.GDgrenadeObjects4= [];
gdjs.level0Code.GDgrenadeObjects5= [];
gdjs.level0Code.GDgrenadeObjects6= [];
gdjs.level0Code.GDgrenadeObjects7= [];
gdjs.level0Code.GDgrenadeObjects8= [];
gdjs.level0Code.GDgrenadeObjects9= [];


gdjs.level0Code.eventsList0 = function(runtimeScene) {

};gdjs.level0Code.eventsList1 = function(runtimeScene) {

};gdjs.level0Code.eventsList2 = function(runtimeScene) {

};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgunObjects2Objects = Hashtable.newFrom({"gun": gdjs.level0Code.GDgunObjects2});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects2Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects2});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects2Objects = Hashtable.newFrom({"shadow": gdjs.level0Code.GDshadowObjects2});
gdjs.level0Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDgunObjects4, gdjs.level0Code.GDgunObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects5[i].getBehavior("FireBullet").BulletQuantity((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects5[0].getVariables()).getFromIndex(11))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects5[k] = gdjs.level0Code.GDgunObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects5 */
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects5[i].getBehavior("FireBullet").SetBulletQuantityOp((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects5[0].getVariables()).getFromIndex(11))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.level0Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDgunObjects2, gdjs.level0Code.GDgunObjects3);


for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDgunObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.level0Code.GDgunObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDgunObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDgunObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects4[i].getVariableString(gdjs.level0Code.GDgunObjects4[i].getVariables().getFromIndex(3)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects4[k] = gdjs.level0Code.GDgunObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList3(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getBehavior("TopDownMovement").getMaxSpeed() != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(10))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(10))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("health_bar"), gdjs.level0Code.GDhealth_9595barObjects3);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDhealth_9595barObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDhealth_9595barObjects3[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(8))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDhealth_9595barObjects3[k] = gdjs.level0Code.GDhealth_9595barObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDhealth_9595barObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDhealth_9595barObjects3 */
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDhealth_9595barObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDhealth_9595barObjects3[i].SetMaxValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(8))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("armor"), gdjs.level0Code.GDarmorObjects3);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDarmorObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDarmorObjects3[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(9))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDarmorObjects3[k] = gdjs.level0Code.GDarmorObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDarmorObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDarmorObjects3 */
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDarmorObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDarmorObjects3[i].SetMaxValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(9))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(8))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].returnVariable(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(8))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(1)) != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(9))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].returnVariable(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(9))));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("health_bar"), gdjs.level0Code.GDhealth_9595barObjects3);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);

{for(var i = 0, len = gdjs.level0Code.GDhealth_9595barObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDhealth_9595barObjects3[i].SetValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.level0Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level_design"), gdjs.level0Code.GDlevel_9595designObjects2);
{for(var i = 0, len = gdjs.level0Code.GDlevel_9595designObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDlevel_9595designObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.sound.preloadSound(runtimeScene, "gun1burst.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "gun3burst.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "sword.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "enemy_death.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "player_hit.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "heal.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "armor_hit.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "bullet_on_object.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "menu_select.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "clock.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "explosion1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "null.wav");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 8, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 10, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 9, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 7, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 6, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 5, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 4, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 3, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 2, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 1, false, 0, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "null.wav", 0, false, 0, 1);
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "DavidKBD - InterstellarPack - 04 - Horsehead Nebula.ogg");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "DavidKBD - InterstellarPack - 04 - Horsehead Nebula.ogg", 12, true, 60, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDbarrelObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDbarrelObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDbarrelObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDbarrelObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects3[i].getVariableNumber(gdjs.level0Code.GDbarrelObjects3[i].getVariables().getFromIndex(0)) != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDbarrelObjects3[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects3[k] = gdjs.level0Code.GDbarrelObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].returnVariable(gdjs.level0Code.GDbarrelObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDbarrelObjects3[i].getVariables().getFromIndex(1))));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDcover_9595boxObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDcover_9595boxObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDcover_9595boxObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDcover_9595boxObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDcover_9595boxObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDcover_9595boxObjects3[i].getVariableNumber(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().getFromIndex(0)) != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDcover_9595boxObjects3[k] = gdjs.level0Code.GDcover_9595boxObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDcover_9595boxObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects3[i].returnVariable(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().getFromIndex(1))));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDsandbagObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDsandbagObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDsandbagObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDsandbagObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDsandbagObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDsandbagObjects3[i].getVariableNumber(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(0)) != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDsandbagObjects3[k] = gdjs.level0Code.GDsandbagObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDsandbagObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDsandbagObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects3[i].returnVariable(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(1))));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects1);

for (gdjs.level0Code.forEachIndex2 = 0;gdjs.level0Code.forEachIndex2 < gdjs.level0Code.GDplayerObjects1.length;++gdjs.level0Code.forEachIndex2) {
gdjs.level0Code.GDgunObjects2.length = 0;

gdjs.level0Code.GDmelee_9595weaponObjects2.length = 0;

gdjs.level0Code.GDshadowObjects2.length = 0;

gdjs.level0Code.GDplayerObjects2.length = 0;


gdjs.level0Code.forEachTemporary2 = gdjs.level0Code.GDplayerObjects1[gdjs.level0Code.forEachIndex2];
gdjs.level0Code.GDplayerObjects2.push(gdjs.level0Code.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects2[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects2[k] = gdjs.level0Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgunObjects2Objects, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterXInScene()) - 32, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterYInScene()) - 32, "");
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects2[i].returnVariable(gdjs.level0Code.GDgunObjects2[i].getVariables().getFromIndex(3)).setString("player");
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects2[i].setZOrder((( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects2[i].getBehavior("Animation").setAnimationName("player_gun");
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects2[i].getBehavior("FireBullet").SetCooldownOp(0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects2Objects, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getPointX("")), (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects2[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects2[i].getVariables().getFromIndex(0)).setString("player");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects2Objects, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterXInScene()) - 24, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterYInScene()) + 22, "");
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects2[i].returnVariable(gdjs.level0Code.GDshadowObjects2[i].getVariables().getFromIndex(0)).setString("player");
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects2[i].setZOrder((( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects2[i].getBehavior("Resizable").setWidth(50);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects2[i].getBehavior("Resizable").setHeight(16);
}
}
{ //Subevents: 
gdjs.level0Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDwave_9595timerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDwave_9595timerObjects4[i].getBehavior("RepeatTimer").Repeat((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects4[k] = gdjs.level0Code.GDwave_9595timerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects4.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "clock.wav", 11, false, 50, gdjs.randomInRange(0.95, 1));
}}

}


};gdjs.level0Code.mapOfEmptyGDenemy_9595spawnerObjects = Hashtable.newFrom({"enemy_spawner": []});
gdjs.level0Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(-(1));
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfEmptyGDenemy_9595spawnerObjects) * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.level0Code.GDdebugObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects4);
gdjs.copyArray(runtimeScene.getObjects("waves_debug"), gdjs.level0Code.GDwaves_9595debugObjects4);
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects4[i].setString("All Waves Completed " + "- Kill count " + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects4[0].getVariables()).getFromIndex(7)))));
}
}{for(var i = 0, len = gdjs.level0Code.GDdebugObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDdebugObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.level0Code.GDwaves_9595debugObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDwaves_9595debugObjects4[i].hide();
}
}}

}


};gdjs.level0Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects4.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDwave_9595timerObjects4[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects4[k] = gdjs.level0Code.GDwave_9595timerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDwave_9595timerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects4[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects4);
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects4[i].setString("Next Wave in " + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)))));
}
}
{ //Subevents
gdjs.level0Code.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7));
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).sub(0.01);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) < 0.5;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects3);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects3[i].setString("Next Wave in " + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)))));
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}}

}


};gdjs.level0Code.mapOfEmptyGDenemyObjectsEmptyGDenemy_9595meleeObjects = Hashtable.newFrom({"enemy": [], "enemy_melee": []});
gdjs.level0Code.mapOfEmptyGDenemyObjectsEmptyGDenemy_9595meleeObjects = Hashtable.newFrom({"enemy": [], "enemy_melee": []});
gdjs.level0Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), true);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), false);
}}

}


};gdjs.level0Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4));
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects = Hashtable.newFrom({"enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4});
gdjs.level0Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDenemy_9595spawnerObjects3, gdjs.level0Code.GDenemy_9595spawnerObjects4);

{for(var i = 0, len = gdjs.level0Code.GDenemy_9595spawnerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595spawnerObjects4[i].returnVariable(gdjs.level0Code.GDenemy_9595spawnerObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(0, 100));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595spawnerObjects3, gdjs.level0Code.GDenemy_9595spawnerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595spawnerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595spawnerObjects4[i].getVariableNumber(gdjs.level0Code.GDenemy_9595spawnerObjects4[i].getVariables().getFromIndex(0)) < 60 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595spawnerObjects4[k] = gdjs.level0Code.GDenemy_9595spawnerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595spawnerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595spawnerObjects4 */
gdjs.level0Code.GDenemy_9595meleeObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects, (( gdjs.level0Code.GDenemy_9595spawnerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595spawnerObjects4[0].getCenterXInScene()) + gdjs.randomInRange(-(128), 128), (( gdjs.level0Code.GDenemy_9595spawnerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595spawnerObjects4[0].getCenterYInScene()) + gdjs.randomInRange(-(128), 128), "");
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595spawnerObjects3, gdjs.level0Code.GDenemy_9595spawnerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595spawnerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595spawnerObjects4[i].getVariableNumber(gdjs.level0Code.GDenemy_9595spawnerObjects4[i].getVariables().getFromIndex(0)) >= 60 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595spawnerObjects4[k] = gdjs.level0Code.GDenemy_9595spawnerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595spawnerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595spawnerObjects4 */
gdjs.level0Code.GDenemyObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects, (( gdjs.level0Code.GDenemy_9595spawnerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595spawnerObjects4[0].getCenterXInScene()) + gdjs.randomInRange(-(128), 128), (( gdjs.level0Code.GDenemy_9595spawnerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595spawnerObjects4[0].getCenterYInScene()) + gdjs.randomInRange(-(128), 128), "");
}}

}


};gdjs.level0Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDwave_9595timerObjects3[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects3[k] = gdjs.level0Code.GDwave_9595timerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDwave_9595timerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfEmptyGDenemyObjectsEmptyGDenemy_9595meleeObjects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfEmptyGDenemyObjectsEmptyGDenemy_9595meleeObjects));
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) <= 1 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1));
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
}
{ //Subevents
gdjs.level0Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy_spawner"), gdjs.level0Code.GDenemy_9595spawnerObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDenemy_9595spawnerObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDenemy_9595spawnerObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDenemy_9595spawnerObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDenemy_9595spawnerObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) > 1 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595spawnerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595spawnerObjects3[i].getBehavior("RepeatTimer").Repeat((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595spawnerObjects3[k] = gdjs.level0Code.GDenemy_9595spawnerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595spawnerObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList11(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects2[i].getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects2[k] = gdjs.level0Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDwave_9595timerObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects2[k] = gdjs.level0Code.GDwave_9595timerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDwave_9595timerObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects2[i].hide();
}
}}

}


};gdjs.level0Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects2.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDwave_9595timerObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects2[k] = gdjs.level0Code.GDwave_9595timerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDwave_9595timerObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDwave_9595timerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDwave_9595timerObjects2[i].getString() != "Press P to Start Next Wave" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDwave_9595timerObjects2[k] = gdjs.level0Code.GDwave_9595timerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDwave_9595timerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDwave_9595timerObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects2[i].setString("Press P to Start Next Wave");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "p");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), true);
}}

}


};gdjs.level0Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList20 = function(runtimeScene) {

};gdjs.level0Code.eventsList21 = function(runtimeScene) {

};gdjs.level0Code.eventsList22 = function(runtimeScene) {

};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects4});
gdjs.level0Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects5);

for (gdjs.level0Code.forEachIndex6 = 0;gdjs.level0Code.forEachIndex6 < gdjs.level0Code.GDgunObjects5.length;++gdjs.level0Code.forEachIndex6) {
gdjs.level0Code.GDgunObjects6.length = 0;


gdjs.level0Code.forEachTemporary6 = gdjs.level0Code.GDgunObjects5[gdjs.level0Code.forEachIndex6];
gdjs.level0Code.GDgunObjects6.push(gdjs.level0Code.forEachTemporary6);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects6[i].getVariableString(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(3)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects6[k] = gdjs.level0Code.GDgunObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects6.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects5);

for (gdjs.level0Code.forEachIndex6 = 0;gdjs.level0Code.forEachIndex6 < gdjs.level0Code.GDmelee_9595weaponObjects5.length;++gdjs.level0Code.forEachIndex6) {
gdjs.level0Code.GDmelee_9595weaponObjects6.length = 0;


gdjs.level0Code.forEachTemporary6 = gdjs.level0Code.GDmelee_9595weaponObjects5[gdjs.level0Code.forEachIndex6];
gdjs.level0Code.GDmelee_9595weaponObjects6.push(gdjs.level0Code.forEachTemporary6);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.level0Code.GDshadowObjects5);

for (gdjs.level0Code.forEachIndex6 = 0;gdjs.level0Code.forEachIndex6 < gdjs.level0Code.GDshadowObjects5.length;++gdjs.level0Code.forEachIndex6) {
gdjs.level0Code.GDshadowObjects6.length = 0;


gdjs.level0Code.forEachTemporary6 = gdjs.level0Code.GDshadowObjects5[gdjs.level0Code.forEachIndex6];
gdjs.level0Code.GDshadowObjects6.push(gdjs.level0Code.forEachTemporary6);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDshadowObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDshadowObjects6[i].getVariableString(gdjs.level0Code.GDshadowObjects6[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDshadowObjects6[k] = gdjs.level0Code.GDshadowObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDshadowObjects6.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDshadowObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects6[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("death_message"), gdjs.level0Code.GDdeath_9595messageObjects5);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);

gdjs.copyArray(runtimeScene.getObjects("wave_timer"), gdjs.level0Code.GDwave_9595timerObjects5);
{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects5[i].setString("Kill count " + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects5[0].getVariables()).getFromIndex(7)))));
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)));
}{for(var i = 0, len = gdjs.level0Code.GDdeath_9595messageObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDdeath_9595messageObjects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.level0Code.GDwave_9595timerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDwave_9595timerObjects5[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDplayerObjects4 */
gdjs.level0Code.GDbloodObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects4[i].setColor("180;0;3");
}
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects4[i].getBehavior("Scale").setScale(2);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].hide();
}
}}

}


};gdjs.level0Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).sub(0.01);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) <= 0.05;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level0", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit_text"), gdjs.level0Code.GDexit_9595textObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects4[i].getX() != 480 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects4[k] = gdjs.level0Code.GDexit_9595textObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects4[i].getY() != 128 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects4[k] = gdjs.level0Code.GDexit_9595textObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexit_9595textObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDexit_9595textObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDexit_9595textObjects4[i].setPosition(480,128);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("exit_text"), gdjs.level0Code.GDexit_9595textObjects3);
{for(var i = 0, len = gdjs.level0Code.GDexit_9595textObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDexit_9595textObjects3[i].setString("RESTARTING IN " + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)))));
}
}}

}


};gdjs.level0Code.eventsList25 = function(runtimeScene) {

};gdjs.level0Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.level0Code.GDshadowObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDshadowObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);

gdjs.level0Code.GDshadowObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDshadowObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDshadowObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDshadowObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDshadowObjects4[i].getVariableString(gdjs.level0Code.GDshadowObjects4[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDshadowObjects4[k] = gdjs.level0Code.GDshadowObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDshadowObjects4.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].setX((( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()) - 24);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].setY((( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()) + 22);
}
}}
}

}


};gdjs.level0Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects6[i].getBehavior("FireBullet").BulletQuantity((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects6[0].getVariables()).getFromIndex(11))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects6[k] = gdjs.level0Code.GDgunObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects6 */
/* Reuse gdjs.level0Code.GDplayerObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].getBehavior("FireBullet").SetBulletQuantityOp((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects6[0].getVariables()).getFromIndex(11))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.level0Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects4);

for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.GDgunObjects4.length;++gdjs.level0Code.forEachIndex5) {
gdjs.level0Code.GDgunObjects5.length = 0;


gdjs.level0Code.forEachTemporary5 = gdjs.level0Code.GDgunObjects4[gdjs.level0Code.forEachIndex5];
gdjs.level0Code.GDgunObjects5.push(gdjs.level0Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects5[i].getVariableString(gdjs.level0Code.GDgunObjects5[i].getVariables().getFromIndex(3)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects5[k] = gdjs.level0Code.GDgunObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList27(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").getMaxSpeed() != (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(10))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(12)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(10))) * 2);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(10))));
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").setAcceleration((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(10))) * 5);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").setDeceleration((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(10))) * 5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("health_bar"), gdjs.level0Code.GDhealth_9595barObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDhealth_9595barObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDhealth_9595barObjects4[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects4[0].getVariables()).getFromIndex(8))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDhealth_9595barObjects4[k] = gdjs.level0Code.GDhealth_9595barObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDhealth_9595barObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDhealth_9595barObjects4 */
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDhealth_9595barObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDhealth_9595barObjects4[i].SetMaxValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects4[0].getVariables()).getFromIndex(8))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("armor"), gdjs.level0Code.GDarmorObjects3);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDarmorObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDarmorObjects3[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(9))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDarmorObjects3[k] = gdjs.level0Code.GDarmorObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDarmorObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDarmorObjects3 */
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDarmorObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDarmorObjects3[i].SetMaxValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects3[0].getVariables()).getFromIndex(9))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects4});
gdjs.level0Code.eventsList29 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDplayerObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].addPolarForce((gdjs.level0Code.GDbulletObjects5[i].getAverageForce().getAngle()), -((gdjs.level0Code.GDbulletObjects5[i].getAverageForce().getLength())) * 2, 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].rotateTowardAngle((gdjs.level0Code.GDbulletObjects5[i].getAverageForce().getAngle()), 0, runtimeScene);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects4});
gdjs.level0Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDbulletObjects4, gdjs.level0Code.GDbulletObjects5);

/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].returnVariable(gdjs.level0Code.GDbulletObjects5[i].getVariables().getFromIndex(0)).setString("ricochet");
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)).sub(5);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "armor_hit.wav", 4, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 4), gdjs.randomFloatInRange(0.85, 1));
}
{ //Subevents
gdjs.level0Code.eventsList29(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects4 */
/* Reuse gdjs.level0Code.GDplayerObjects4 */
gdjs.level0Code.GDbloodObjects4.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDbulletObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)).sub(10);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects4[i].setColor("180;0;3");
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects4});
gdjs.level0Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)).sub(10);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "armor_hit.wav", 4, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 4), gdjs.randomFloatInRange(0.85, 1));
}}

}


{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
gdjs.level0Code.GDbloodObjects4.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)).sub(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects4[i].setColor("180;0;3");
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects4});
gdjs.level0Code.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDexplosionObjects4, gdjs.level0Code.GDexplosionObjects5);

/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects5[0].getVariables()).getFromIndex(0))));
}
}}

}


{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
/* Reuse gdjs.level0Code.GDplayerObjects4 */
gdjs.level0Code.GDbloodObjects4.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects4[0].getVariables()).getFromIndex(0))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects4[i].setColor("180;0;3");
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDhealth_95959595kitObjects4Objects = Hashtable.newFrom({"health_kit": gdjs.level0Code.GDhealth_9595kitObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)).setNumber(10);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setColor("255;0;0");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)).sub(1);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(3), false);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects, 32, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects4[i].getVariableString(gdjs.level0Code.GDbulletObjects4[i].getVariables().getFromIndex(0)) != "player" ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDbulletObjects4[k] = gdjs.level0Code.GDbulletObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects4[i].getVariableString(gdjs.level0Code.GDbulletObjects4[i].getVariables().getFromIndex(0)) != "ricochet" ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDbulletObjects4[k] = gdjs.level0Code.GDbulletObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects4.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariables().getFromIndex(0)) != "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects4[k] = gdjs.level0Code.GDmelee_9595weaponObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects4[k] = gdjs.level0Code.GDmelee_9595weaponObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects4.length = k;
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("explosion"), gdjs.level0Code.GDexplosionObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getVariableBoolean(gdjs.level0Code.GDexplosionObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("health_kit"), gdjs.level0Code.GDhealth_9595kitObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)) < (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(8))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDhealth_95959595kitObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, 32, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDhealth_9595kitObjects4 */
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDhealth_9595kitObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDhealth_9595kitObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDhealth_9595kitObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDhealth_9595kitObjects4[0].getVariables()).getFromIndex(0))));
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "heal.wav", 6, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 6), 1);
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)) > (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(8))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(8))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(1)) > (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(9))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].returnVariable(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(9))));
}
}}

}


};gdjs.level0Code.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects6);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects6[i].getBehavior("TopDownMovement").simulateUpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects6);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects6[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects6);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects6[i].getBehavior("TopDownMovement").simulateDownKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3)));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].getBehavior("TopDownMovement").simulateRightKey();
}
}}

}


};gdjs.level0Code.asyncCallback14671228 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level0Code.GDplayerObjects6);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects6[i].returnVariable(gdjs.level0Code.GDplayerObjects6[i].getVariables().getFromIndex(5)).setNumber(3);
}
}}
gdjs.level0Code.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.level0Code.GDplayerObjects5) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.level0Code.asyncCallback14671228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.asyncCallback14673476 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level0Code.GDplayerObjects5);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)).setNumber(0);
}
}}
gdjs.level0Code.eventsList36 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.level0Code.GDplayerObjects4) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects4[0].getVariables()).getFromIndex(14)))), (runtimeScene) => (gdjs.level0Code.asyncCallback14673476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(5)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(5)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)).setNumber(2);
}
}
{ //Subevents
gdjs.level0Code.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(5)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].addPolarForce((gdjs.level0Code.GDplayerObjects5[i].getBehavior("TopDownMovement").getAngle()), (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(12))), 0);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].setColor("255;255;255");
}
}}

}


{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(5)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].setBlendMode(0);
}
}
{ //Subevents
gdjs.level0Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList38 = function(runtimeScene) {

{


gdjs.level0Code.eventsList34(runtimeScene);
}


{


gdjs.level0Code.eventsList37(runtimeScene);
}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects4Objects = Hashtable.newFrom({"sandbag": gdjs.level0Code.GDsandbagObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDwallObjects3Objects = Hashtable.newFrom({"wall": gdjs.level0Code.GDwallObjects3});
gdjs.level0Code.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(21), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList38(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("Animation").setAnimationName("walking");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").getXVelocity() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getBehavior("TopDownMovement").getXVelocity() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDplayerObjects4[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);

{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects4[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);

{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects4[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects4Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects3);
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDwallObjects3Objects, false);
}
}}

}


};gdjs.level0Code.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects4, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects5[i].returnVariable(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(16)).sub((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(20))) * 4);
}
}}

}


{

/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16)).sub((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(20))));
}
}}

}


};gdjs.level0Code.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16)) > (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(17))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(17))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16)) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(13)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(18))) - (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(18))) * ((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16))) / 106));
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(14)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(19))) - (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(19))) * ((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(16))) / 106));
}
}
{ //Subevents
gdjs.level0Code.eventsList40(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(16)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].returnVariable(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(16)).setNumber(0);
}
}}

}


};gdjs.level0Code.eventsList42 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].toggleVariableBoolean(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(2));
}
}}

}


};gdjs.level0Code.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)));
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList42(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList44 = function(runtimeScene) {

};gdjs.level0Code.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects4);

for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.GDmelee_9595weaponObjects4.length;++gdjs.level0Code.forEachIndex5) {
gdjs.level0Code.GDmelee_9595weaponObjects5.length = 0;


gdjs.level0Code.forEachTemporary5 = gdjs.level0Code.GDmelee_9595weaponObjects4[gdjs.level0Code.forEachIndex5];
gdjs.level0Code.GDmelee_9595weaponObjects5.push(gdjs.level0Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].hide();
}
}}
}

}


};gdjs.level0Code.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Animation").setAnimationName("player_sword_b");
}
}}

}


{

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
/* Reuse gdjs.level0Code.GDplayerObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getZOrder() != (( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getZOrder()) - 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setZOrder((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getZOrder()) - 1);
}
}}

}


};gdjs.level0Code.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Animation").setAnimationName("player_sword_f");
}
}}

}


{

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
/* Reuse gdjs.level0Code.GDplayerObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getZOrder() != (( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getZOrder()) + 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setZOrder((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getZOrder()) + 1);
}
}}

}


};gdjs.level0Code.eventsList48 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(3), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(2), false);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects6Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects6Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects6});
gdjs.level0Code.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects6);
gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects6Objects, (( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getCenterYInScene()), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects6Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects, 96, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects6 */
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].rotateTowardPosition((( gdjs.level0Code.GDenemyObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects6[0].getCenterXInScene()), -((( gdjs.level0Code.GDenemyObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects6[0].getCenterYInScene())), 0, runtimeScene);
}
}}

}


};gdjs.level0Code.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableNumber(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Animation").setAnimationName("combo01-1");
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(1)).add(1);
}
}
{ //Subevents
gdjs.level0Code.eventsList49(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].rotateTowardAngle(0, 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(3), false);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(1)).setNumber(0);
}
}}

}


};gdjs.level0Code.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Animation").getAnimationSpeedScale() == (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects5[0].getVariables()).getFromIndex(13))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDmelee_9595weaponObjects5[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);

/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setX((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getPointX("")) - 40);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setY((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getPointY("")));
}
}
{ //Subevents
gdjs.level0Code.eventsList46(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDplayerObjects5[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);

/* Reuse gdjs.level0Code.GDplayerObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setX((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setY((( gdjs.level0Code.GDplayerObjects5.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects5[0].getPointY("")));
}
}
{ //Subevents
gdjs.level0Code.eventsList47(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects5[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects5[i].getVariables().getFromIndex(21), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects5[k] = gdjs.level0Code.GDplayerObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(2), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList48(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList50(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects4, gdjs.level0Code.GDmelee_9595weaponObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects5[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(2), true);
}
}}

}


};gdjs.level0Code.eventsList52 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDmelee_9595weaponObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.level0Code.GDmelee_9595weaponObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDmelee_9595weaponObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDmelee_9595weaponObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects4[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects4[k] = gdjs.level0Code.GDmelee_9595weaponObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList51(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(2)) != 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList45(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList54 = function(runtimeScene) {

};gdjs.level0Code.eventsList55 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects4);

for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.GDgunObjects4.length;++gdjs.level0Code.forEachIndex5) {
gdjs.level0Code.GDgunObjects5.length = 0;


gdjs.level0Code.forEachTemporary5 = gdjs.level0Code.GDgunObjects4[gdjs.level0Code.forEachIndex5];
gdjs.level0Code.GDgunObjects5.push(gdjs.level0Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects5[i].getVariableString(gdjs.level0Code.GDgunObjects5[i].getVariables().getFromIndex(3)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects5[k] = gdjs.level0Code.GDgunObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects5[k] = gdjs.level0Code.GDgunObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects5.length = k;
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDgunObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects5[i].hide();
}
}}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects6Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects6});
gdjs.level0Code.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);

gdjs.level0Code.GDbulletObjects6.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].returnVariable(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(1)).setNumber(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].returnVariable(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(2)).setNumber(gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].getBehavior("FireBullet").Fire((gdjs.level0Code.GDgunObjects6[i].getCenterXInScene()), (gdjs.level0Code.GDgunObjects6[i].getCenterYInScene()), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects6Objects, Math.atan2((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(2))) - (gdjs.level0Code.GDgunObjects6[i].getCenterYInScene()), (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(1))) - (gdjs.level0Code.GDgunObjects6[i].getCenterXInScene())) * 180 / gdjs.evtTools.common.pi(), 1000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDbulletObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects6[i].returnVariable(gdjs.level0Code.GDbulletObjects6[i].getVariables().getFromIndex(0)).setString((gdjs.RuntimeObject.getVariableString(((gdjs.level0Code.GDgunObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDgunObjects6[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.level0Code.GDbulletObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects6[i].setZOrder((( gdjs.level0Code.GDgunObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDgunObjects6[0].getZOrder()) - 1);
}
}}

}


};gdjs.level0Code.eventsList57 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects6.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDgunObjects6[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects6[k] = gdjs.level0Code.GDgunObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects6);

{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].setX((( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getCenterXInScene()) - 32);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].setY((( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getCenterYInScene()) - 32);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);

{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].returnVariable(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(0)).setNumber(Math.round(Math.abs((gdjs.level0Code.GDgunObjects6[i].getAngle()))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects6[i].getVariableNumber(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(0)) <= 90 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects6[k] = gdjs.level0Code.GDgunObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].flipY(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgunObjects5, gdjs.level0Code.GDgunObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects6[i].getVariableNumber(gdjs.level0Code.GDgunObjects6[i].getVariables().getFromIndex(0)) > 90 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects6[k] = gdjs.level0Code.GDgunObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects6[i].flipY(true);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects6[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects6[i].getVariables().getFromIndex(21), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects6[k] = gdjs.level0Code.GDplayerObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList56(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects5});
gdjs.level0Code.eventsList58 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects4, gdjs.level0Code.GDbulletObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects, 40, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].hide();
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects4, gdjs.level0Code.GDbulletObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects, 40, true);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects4, gdjs.level0Code.GDbulletObjects5);

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects5Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects5Objects, 1000, true);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects5[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level0Code.eventsList59 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects4);

for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.GDgunObjects4.length;++gdjs.level0Code.forEachIndex5) {
gdjs.level0Code.GDgunObjects5.length = 0;


gdjs.level0Code.forEachTemporary5 = gdjs.level0Code.GDgunObjects4[gdjs.level0Code.forEachIndex5];
gdjs.level0Code.GDgunObjects5.push(gdjs.level0Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects5[i].getVariableString(gdjs.level0Code.GDgunObjects5[i].getVariables().getFromIndex(3)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects5[k] = gdjs.level0Code.GDgunObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList57(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDbulletObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.level0Code.GDbulletObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDbulletObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDbulletObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects4[i].getVariableString(gdjs.level0Code.GDbulletObjects4[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects4[k] = gdjs.level0Code.GDbulletObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList58(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList60 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(2)) != 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList55(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects2, gdjs.level0Code.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList59(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects2Objects = Hashtable.newFrom({"grenade": gdjs.level0Code.GDgrenadeObjects2});
gdjs.level0Code.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(6)));
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects2 */
gdjs.level0Code.GDgrenadeObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects2Objects, (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects2[i].addForceTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 400, 1);
}
}}

}


};gdjs.level0Code.eventsList62 = function(runtimeScene) {

{


gdjs.level0Code.eventsList41(runtimeScene);
}


{


gdjs.level0Code.eventsList43(runtimeScene);
}


{


gdjs.level0Code.eventsList53(runtimeScene);
}


{


gdjs.level0Code.eventsList60(runtimeScene);
}


{


gdjs.level0Code.eventsList61(runtimeScene);
}


};gdjs.level0Code.eventsList63 = function(runtimeScene) {

{


gdjs.level0Code.eventsList26(runtimeScene);
}


{


gdjs.level0Code.eventsList28(runtimeScene);
}


{


gdjs.level0Code.eventsList33(runtimeScene);
}


{


gdjs.level0Code.eventsList39(runtimeScene);
}


{


gdjs.level0Code.eventsList62(runtimeScene);
}


};gdjs.level0Code.eventsList64 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList24(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects2[i].getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects2[k] = gdjs.level0Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects8Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects8, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects8Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects8Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects8});
gdjs.level0Code.eventsList65 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), true);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), true);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects8Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects8, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects8Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects8Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects8});
gdjs.level0Code.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects8);
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects8[i].returnVariable(gdjs.level0Code.GDplayerObjects8[i].getVariables().getFromIndex(0)).add(25);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects8[i].returnVariable(gdjs.level0Code.GDplayerObjects8[i].getVariables().getFromIndex(16)).add(25);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects7Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects7Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects7});
gdjs.level0Code.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDenemyObjects7 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects7 */
/* Reuse gdjs.level0Code.GDexplosionObjects7 */
gdjs.level0Code.GDbloodObjects7.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects7[i].getVariables().get("got_hit"), true);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects7[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects7[i].getVariables().get("got_hit"), true);
}
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].returnVariable(gdjs.level0Code.GDenemyObjects7[i].getVariables().get("health")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects7[0].getVariables()).getFromIndex(0))));
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects7[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects7[i].getVariables().get("health")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects7[0].getVariables()).getFromIndex(0))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects7Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects7.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects7[0].getCenterXInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects7[0].getCenterXInScene()), (( gdjs.level0Code.GDenemy_9595meleeObjects7.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects7[0].getCenterYInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects7[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects7[i].setColor("255;0;62");
}
}}

}


};gdjs.level0Code.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableNumber(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].returnVariable(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")).setNumber(10);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")).setNumber(10);
}
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].setColor("255;0;0");
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].setColor("255;0;0");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableNumber(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].returnVariable(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")).sub(1);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")).sub(1);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableNumber(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), false);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), false);
}
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects8);
gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects8Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects8Objects, 32, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.level0Code.GDbulletObjects8_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDbulletObjects8, gdjs.level0Code.GDbulletObjects9);

for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects9.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects9[i].getVariableString(gdjs.level0Code.GDbulletObjects9[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDbulletObjects9[k] = gdjs.level0Code.GDbulletObjects9[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects9.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbulletObjects9.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbulletObjects8_1final.indexOf(gdjs.level0Code.GDbulletObjects9[j]) === -1 )
            gdjs.level0Code.GDbulletObjects8_1final.push(gdjs.level0Code.GDbulletObjects9[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level0Code.GDbulletObjects8, gdjs.level0Code.GDbulletObjects9);

for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects9.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects9[i].getVariableString(gdjs.level0Code.GDbulletObjects9[i].getVariables().getFromIndex(0)) == "ricochet" ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDbulletObjects9[k] = gdjs.level0Code.GDbulletObjects9[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects9.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbulletObjects9.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbulletObjects8_1final.indexOf(gdjs.level0Code.GDbulletObjects9[j]) === -1 )
            gdjs.level0Code.GDbulletObjects8_1final.push(gdjs.level0Code.GDbulletObjects9[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level0Code.GDbulletObjects8_1final, gdjs.level0Code.GDbulletObjects8);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects8 */
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
gdjs.level0Code.GDbloodObjects8.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDbulletObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects8[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "bullet_on_object.wav", 7, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 7), gdjs.randomFloatInRange(0.85, 1));
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].returnVariable(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("health")).sub(10);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("health")).sub(10);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects8Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterXInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects8[0].getCenterXInScene()), (( gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterYInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects8[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects8[i].setColor("255;0;62");
}
}
{ //Subevents
gdjs.level0Code.eventsList65(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects8);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects8Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects8Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects8[k] = gdjs.level0Code.GDmelee_9595weaponObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects8.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects8[k] = gdjs.level0Code.GDmelee_9595weaponObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects8.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects8[i].getVariableNumber(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects8[k] = gdjs.level0Code.GDenemyObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects8.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects8[k] = gdjs.level0Code.GDenemy_9595meleeObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects8.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects8 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects8 */
gdjs.level0Code.GDbloodObjects8.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].returnVariable(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("health")).sub(20);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("health")).sub(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects8Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterXInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects8[0].getCenterXInScene()), (( gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterYInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects8[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects8[i].setColor("255;0;62");
}
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects8[i].getVariables().get("got_hit"), true);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects8[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects8[i].getVariables().get("got_hit"), true);
}
}
{ //Subevents
gdjs.level0Code.eventsList66(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects7);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects7);

gdjs.copyArray(runtimeScene.getObjects("explosion"), gdjs.level0Code.GDexplosionObjects7);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects7[i].getVariableNumber(gdjs.level0Code.GDenemyObjects7[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects7[k] = gdjs.level0Code.GDenemyObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects7.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects7[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects7[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects7[k] = gdjs.level0Code.GDenemy_9595meleeObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects7.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects7Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects7[i].getVariableBoolean(gdjs.level0Code.GDexplosionObjects7[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects7[k] = gdjs.level0Code.GDexplosionObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects7.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList69 = function(runtimeScene) {

};gdjs.level0Code.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.level0Code.GDshadowObjects6);

for (gdjs.level0Code.forEachIndex7 = 0;gdjs.level0Code.forEachIndex7 < gdjs.level0Code.GDshadowObjects6.length;++gdjs.level0Code.forEachIndex7) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects7);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects7);

gdjs.level0Code.GDshadowObjects7.length = 0;


gdjs.level0Code.forEachTemporary7 = gdjs.level0Code.GDshadowObjects6[gdjs.level0Code.forEachIndex7];
gdjs.level0Code.GDshadowObjects7.push(gdjs.level0Code.forEachTemporary7);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDshadowObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDshadowObjects7[i].getVariableString(gdjs.level0Code.GDshadowObjects7[i].getVariables().getFromIndex(0)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects7.length === 0 ) ? ((gdjs.level0Code.GDenemyObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects7[0].getVariables()) : gdjs.level0Code.GDenemy_9595meleeObjects7[0].getVariables()).get("id")))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDshadowObjects7[k] = gdjs.level0Code.GDshadowObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDshadowObjects7.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDshadowObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects7[i].setX((( gdjs.level0Code.GDenemy_9595meleeObjects7.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects7[0].getCenterXInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects7[0].getCenterXInScene()) - 24);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects7[i].setY((( gdjs.level0Code.GDenemy_9595meleeObjects7.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects7[0].getCenterYInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects7[0].getCenterYInScene()) + 22);
}
}}
}

}


};gdjs.level0Code.eventsList71 = function(runtimeScene) {

{


gdjs.level0Code.eventsList68(runtimeScene);
}


{


gdjs.level0Code.eventsList70(runtimeScene);
}


};gdjs.level0Code.eventsList72 = function(runtimeScene) {

};gdjs.level0Code.eventsList73 = function(runtimeScene) {

};gdjs.level0Code.eventsList74 = function(runtimeScene) {

};gdjs.level0Code.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "enemy_death.wav", 2, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 2), gdjs.randomFloatInRange(0.8, 1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.level0Code.GDshadowObjects7);

for (gdjs.level0Code.forEachIndex8 = 0;gdjs.level0Code.forEachIndex8 < gdjs.level0Code.GDshadowObjects7.length;++gdjs.level0Code.forEachIndex8) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);

gdjs.level0Code.GDshadowObjects8.length = 0;


gdjs.level0Code.forEachTemporary8 = gdjs.level0Code.GDshadowObjects7[gdjs.level0Code.forEachIndex8];
gdjs.level0Code.GDshadowObjects8.push(gdjs.level0Code.forEachTemporary8);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDshadowObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDshadowObjects8[i].getVariableString(gdjs.level0Code.GDshadowObjects8[i].getVariables().getFromIndex(0)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? ((gdjs.level0Code.GDenemyObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects8[0].getVariables()) : gdjs.level0Code.GDenemy_9595meleeObjects8[0].getVariables()).get("id")))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDshadowObjects8[k] = gdjs.level0Code.GDshadowObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDshadowObjects8.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDshadowObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects8[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects7);

for (gdjs.level0Code.forEachIndex8 = 0;gdjs.level0Code.forEachIndex8 < gdjs.level0Code.GDgunObjects7.length;++gdjs.level0Code.forEachIndex8) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);

gdjs.level0Code.GDgunObjects8.length = 0;


gdjs.level0Code.forEachTemporary8 = gdjs.level0Code.GDgunObjects7[gdjs.level0Code.forEachIndex8];
gdjs.level0Code.GDgunObjects8.push(gdjs.level0Code.forEachTemporary8);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects8[i].getVariableString(gdjs.level0Code.GDgunObjects8[i].getVariables().getFromIndex(3)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? ((gdjs.level0Code.GDenemyObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects8[0].getVariables()) : gdjs.level0Code.GDenemy_9595meleeObjects8[0].getVariables()).get("id")))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects8[k] = gdjs.level0Code.GDgunObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects8.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects7);

for (gdjs.level0Code.forEachIndex8 = 0;gdjs.level0Code.forEachIndex8 < gdjs.level0Code.GDmelee_9595weaponObjects7.length;++gdjs.level0Code.forEachIndex8) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects6, gdjs.level0Code.GDenemy_9595meleeObjects8);

gdjs.level0Code.GDmelee_9595weaponObjects8.length = 0;


gdjs.level0Code.forEachTemporary8 = gdjs.level0Code.GDmelee_9595weaponObjects7[gdjs.level0Code.forEachIndex8];
gdjs.level0Code.GDmelee_9595weaponObjects8.push(gdjs.level0Code.forEachTemporary8);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects8[i].getVariables().getFromIndex(0)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects8.length === 0 ) ? ((gdjs.level0Code.GDenemyObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects8[0].getVariables()) : gdjs.level0Code.GDenemy_9595meleeObjects8[0].getVariables()).get("id")))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects8[k] = gdjs.level0Code.GDmelee_9595weaponObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects8.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects8[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDenemyObjects6 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects6);
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects6[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects6[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects6[i].returnVariable(gdjs.level0Code.GDplayerObjects6[i].getVariables().getFromIndex(7)).add(1);
}
}}

}


};gdjs.level0Code.eventsList76 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects6);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects5, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects6[i].getVariableNumber(gdjs.level0Code.GDenemyObjects6[i].getVariables().get("health")) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects6[k] = gdjs.level0Code.GDenemyObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects6.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects6[i].getVariables().get("health")) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList71(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects6);

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects5, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects6[i].getVariableNumber(gdjs.level0Code.GDenemyObjects6[i].getVariables().get("health")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects6[k] = gdjs.level0Code.GDenemyObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects6.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects6[i].getVariables().get("health")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList75(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects4});
gdjs.level0Code.asyncCallback14730396 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("enemy"), gdjs.level0Code.GDenemyObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects5);

{for(var i = 0, len = gdjs.level0Code.GDenemyObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects5[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDenemyObjects5[i].getVariables().get("max_speed"))));
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects5[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects5[i].getVariables().get("max_speed"))));
}
}}
gdjs.level0Code.eventsList77 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.level0Code.GDenemyObjects4) asyncObjectsList.addObject("enemy", obj);
for (const obj of gdjs.level0Code.GDenemy_9595meleeObjects4) asyncObjectsList.addObject("enemy_melee", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.level0Code.asyncCallback14730396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList78 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDenemyObjects4 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects4[i].getBehavior("Pathfinding").getMaxSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects4[k] = gdjs.level0Code.GDenemyObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects4[i].getBehavior("Pathfinding").getMaxSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects4[k] = gdjs.level0Code.GDenemy_9595meleeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects4 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects4[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects4[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
}
{ //Subevents
gdjs.level0Code.eventsList77(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList79 = function(runtimeScene) {

{

/* Reuse gdjs.level0Code.GDenemyObjects4 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects4 */
/* Reuse gdjs.level0Code.GDplayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getPointX("")), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getPointY("")), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList78(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects3ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects3Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects3, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects3Objects = Hashtable.newFrom({"blood": gdjs.level0Code.GDbloodObjects3});
gdjs.level0Code.eventsList80 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects4);

gdjs.level0Code.forEachTotalCount5 = 0;
gdjs.level0Code.forEachObjects5.length = 0;
gdjs.level0Code.forEachCount0_5 = gdjs.level0Code.GDenemyObjects4.length;
gdjs.level0Code.forEachTotalCount5 += gdjs.level0Code.forEachCount0_5;
gdjs.level0Code.forEachObjects5.push.apply(gdjs.level0Code.forEachObjects5,gdjs.level0Code.GDenemyObjects4);
gdjs.level0Code.forEachCount1_5 = gdjs.level0Code.GDenemy_9595meleeObjects4.length;
gdjs.level0Code.forEachTotalCount5 += gdjs.level0Code.forEachCount1_5;
gdjs.level0Code.forEachObjects5.push.apply(gdjs.level0Code.forEachObjects5,gdjs.level0Code.GDenemy_9595meleeObjects4);
for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.forEachTotalCount5;++gdjs.level0Code.forEachIndex5) {
gdjs.level0Code.GDenemyObjects5.length = 0;

gdjs.level0Code.GDenemy_9595meleeObjects5.length = 0;


if (gdjs.level0Code.forEachIndex5 < gdjs.level0Code.forEachCount0_5) {
    gdjs.level0Code.GDenemyObjects5.push(gdjs.level0Code.forEachObjects5[gdjs.level0Code.forEachIndex5]);
}
else if (gdjs.level0Code.forEachIndex5 < gdjs.level0Code.forEachCount0_5+gdjs.level0Code.forEachCount1_5) {
    gdjs.level0Code.GDenemy_9595meleeObjects5.push(gdjs.level0Code.forEachObjects5[gdjs.level0Code.forEachIndex5]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList76(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects4);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects4.length === 0 ) ? ((gdjs.level0Code.GDenemyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects4[0].getVariables()) : gdjs.level0Code.GDenemy_9595meleeObjects4[0].getVariables()).get("firing_distance"))), false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects4Objects, 96, false);
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList79(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(5)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects3[i].getVariableNumber(gdjs.level0Code.GDenemyObjects3[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects3[k] = gdjs.level0Code.GDenemyObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().get("damage_cooldown")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects3[k] = gdjs.level0Code.GDenemy_9595meleeObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects3ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects3Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects3Objects, 64, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects3 */
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects3 */
gdjs.level0Code.GDbloodObjects3.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDenemyObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects3[i].returnVariable(gdjs.level0Code.GDenemyObjects3[i].getVariables().get("health")).sub(20);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects3[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().get("health")).sub(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbloodObjects3Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects3[0].getCenterXInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterXInScene()), (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? (( gdjs.level0Code.GDenemyObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects3[0].getCenterYInScene()) :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects3[i].getBehavior("Scale").setScale(1.5);
}
}{for(var i = 0, len = gdjs.level0Code.GDbloodObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects3[i].setColor("255;0;62");
}
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects3[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects3[i].getVariables().get("got_hit"), true);
}
for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects3[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().get("got_hit"), true);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfEmptyGDenemyObjects = Hashtable.newFrom({"enemy": []});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects7});
gdjs.level0Code.eventsList81 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects7);

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects7);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects7[i].getBehavior("Pathfinding").getMaxSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects7[k] = gdjs.level0Code.GDenemyObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects7.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects7[0].getVariables()).getFromIndex(6))), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects7[0].getVariables()).getFromIndex(7))), true);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects7 */
/* Reuse gdjs.level0Code.GDplayerObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, ((( gdjs.level0Code.GDplayerObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects7[0].getPointX("")) + (gdjs.level0Code.GDenemyObjects7[i].getPointX(""))) / 2, ((( gdjs.level0Code.GDplayerObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects7[0].getPointY("")) + (gdjs.level0Code.GDenemyObjects7[i].getPointY(""))) / 2);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects7[i].getBehavior("Pathfinding").getSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects7[k] = gdjs.level0Code.GDenemyObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].getBehavior("Animation").setAnimationName("walk");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects7[i].getBehavior("Pathfinding").getSpeed() <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects7[k] = gdjs.level0Code.GDenemyObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects7.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDenemyObjects7[i].getBehavior("Pathfinding").movementAngleIsAround(0, 90)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects7[k] = gdjs.level0Code.GDenemyObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects7[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects6[i].getBehavior("Pathfinding").movementAngleIsAround(0, 90) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects6[k] = gdjs.level0Code.GDenemyObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemyObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects6[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects8Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects8Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects8});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects8Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects8});
gdjs.level0Code.eventsList82 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects7, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects8);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects8Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects8Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects8[0].getVariables()).getFromIndex(5))), false);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDgunObjects7, gdjs.level0Code.GDgunObjects8);

/* Reuse gdjs.level0Code.GDplayerObjects8 */
gdjs.level0Code.GDbulletObjects8.length = 0;

{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].getBehavior("FireBullet").FireTowardObject((gdjs.level0Code.GDgunObjects8[i].getCenterXInScene()), (gdjs.level0Code.GDgunObjects8[i].getCenterYInScene()), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects8Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects8Objects, 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDbulletObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects8[i].returnVariable(gdjs.level0Code.GDbulletObjects8[i].getVariables().getFromIndex(0)).setString((gdjs.RuntimeObject.getVariableString(((gdjs.level0Code.GDgunObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDgunObjects8[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.level0Code.GDbulletObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects8[i].setZOrder((( gdjs.level0Code.GDgunObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDgunObjects8[0].getZOrder()) - 1);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDenemyObjects7, gdjs.level0Code.GDenemyObjects8);

gdjs.copyArray(gdjs.level0Code.GDgunObjects7, gdjs.level0Code.GDgunObjects8);

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects8);
{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].setX((( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterXInScene()) - 32);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].setY((( gdjs.level0Code.GDenemyObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects8[0].getCenterYInScene()) - 32);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].rotateTowardPosition((( gdjs.level0Code.GDplayerObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects8[0].getPointX("")), (( gdjs.level0Code.GDplayerObjects8.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects8[0].getPointY("")), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.level0Code.GDgunObjects7, gdjs.level0Code.GDgunObjects8);

{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].returnVariable(gdjs.level0Code.GDgunObjects8[i].getVariables().getFromIndex(0)).setNumber(Math.round(Math.abs((gdjs.level0Code.GDgunObjects8[i].getAngle()))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgunObjects7, gdjs.level0Code.GDgunObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects8[i].getVariableNumber(gdjs.level0Code.GDgunObjects8[i].getVariables().getFromIndex(0)) <= 90 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects8[k] = gdjs.level0Code.GDgunObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects8.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].flipY(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgunObjects7, gdjs.level0Code.GDgunObjects8);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects8.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects8[i].getVariableNumber(gdjs.level0Code.GDgunObjects8[i].getVariables().getFromIndex(0)) > 90 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects8[k] = gdjs.level0Code.GDgunObjects8[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects8.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgunObjects8 */
{for(var i = 0, len = gdjs.level0Code.GDgunObjects8.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects8[i].flipY(true);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.eventsList83 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects6, gdjs.level0Code.GDbulletObjects7);

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, 40, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects7[i].hide();
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects6, gdjs.level0Code.GDbulletObjects7);

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, 40, true);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects7[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects6, gdjs.level0Code.GDbulletObjects7);

gdjs.copyArray(gdjs.level0Code.GDenemyObjects6, gdjs.level0Code.GDenemyObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, 1000, true);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects7[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level0Code.eventsList84 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.level0Code.GDgunObjects6);

for (gdjs.level0Code.forEachIndex7 = 0;gdjs.level0Code.forEachIndex7 < gdjs.level0Code.GDgunObjects6.length;++gdjs.level0Code.forEachIndex7) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects7);

gdjs.level0Code.GDgunObjects7.length = 0;


gdjs.level0Code.forEachTemporary7 = gdjs.level0Code.GDgunObjects6[gdjs.level0Code.forEachIndex7];
gdjs.level0Code.GDgunObjects7.push(gdjs.level0Code.forEachTemporary7);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgunObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDgunObjects7[i].getVariableString(gdjs.level0Code.GDgunObjects7[i].getVariables().getFromIndex(3)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects7[0].getVariables()).getFromIndex(0)))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgunObjects7[k] = gdjs.level0Code.GDgunObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDgunObjects7.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList82(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects5);

for (gdjs.level0Code.forEachIndex6 = 0;gdjs.level0Code.forEachIndex6 < gdjs.level0Code.GDbulletObjects5.length;++gdjs.level0Code.forEachIndex6) {
gdjs.copyArray(gdjs.level0Code.GDenemyObjects5, gdjs.level0Code.GDenemyObjects6);

gdjs.level0Code.GDbulletObjects6.length = 0;


gdjs.level0Code.forEachTemporary6 = gdjs.level0Code.GDbulletObjects5[gdjs.level0Code.forEachIndex6];
gdjs.level0Code.GDbulletObjects6.push(gdjs.level0Code.forEachTemporary6);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects6[i].getVariableString(gdjs.level0Code.GDbulletObjects6[i].getVariables().getFromIndex(0)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects6[0].getVariables()).getFromIndex(0)))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects6[k] = gdjs.level0Code.GDbulletObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList83(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList85 = function(runtimeScene) {

{


gdjs.level0Code.eventsList81(runtimeScene);
}


{


gdjs.level0Code.eventsList84(runtimeScene);
}


};gdjs.level0Code.eventsList86 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemyObjects4, gdjs.level0Code.GDenemyObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects5[i].getVariableNumber(gdjs.level0Code.GDenemyObjects5[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects5[k] = gdjs.level0Code.GDenemyObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList85(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList87 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects4);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 3));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects4[0].getVariables()).getFromIndex(5))), false);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "gun3burst.wav", 3, true, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 3), gdjs.evtTools.sound.getSoundOnChannelPitch(runtimeScene, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfEmptyGDenemyObjects) <= 0;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects4);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects, (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterXInScene()), (( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getCenterYInScene()), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects4Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects4[0].getVariables()).getFromIndex(5))), true);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDenemyObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.level0Code.GDenemyObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDenemyObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDenemyObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList86(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects = Hashtable.newFrom({"enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects = Hashtable.newFrom({"enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects6});
gdjs.level0Code.eventsList88 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects6);

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Pathfinding").getMaxSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects6[0].getVariables()).getFromIndex(6))), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects6[0].getVariables()).getFromIndex(7))), true);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
/* Reuse gdjs.level0Code.GDplayerObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Pathfinding").moveTo(runtimeScene, ((( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getPointX("")) + (gdjs.level0Code.GDenemy_9595meleeObjects6[i].getPointX(""))) / 2, ((( gdjs.level0Code.GDplayerObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects6[0].getPointY("")) + (gdjs.level0Code.GDenemy_9595meleeObjects6[i].getPointY(""))) / 2);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Pathfinding").getSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Animation").setAnimationName("walk");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Pathfinding").getSpeed() <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Pathfinding").movementAngleIsAround(0, 90)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects5[i].getBehavior("Pathfinding").movementAngleIsAround(0, 90) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects5[k] = gdjs.level0Code.GDenemy_9595meleeObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects5[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.level0Code.eventsList89 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects6, gdjs.level0Code.GDmelee_9595weaponObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects7[k] = gdjs.level0Code.GDmelee_9595weaponObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].getBehavior("Animation").setAnimationName("player_sword_f");
}
}}

}


{

/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getZOrder() != (( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getZOrder()) + 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setZOrder((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getZOrder()) + 1);
}
}}

}


};gdjs.level0Code.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects6, gdjs.level0Code.GDmelee_9595weaponObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects7[k] = gdjs.level0Code.GDmelee_9595weaponObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].getBehavior("Animation").setAnimationName("player_sword_b");
}
}}

}


{

/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getZOrder() != (( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getZOrder()) - 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setZOrder((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getZOrder()) - 1);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects = Hashtable.newFrom({"enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects6});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects6});
gdjs.level0Code.eventsList91 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects5, gdjs.level0Code.GDenemy_9595meleeObjects6);

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects6Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects6Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects6[0].getVariables()).getFromIndex(5))), false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(2), false);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), true);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects7});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects = Hashtable.newFrom({"player": gdjs.level0Code.GDplayerObjects7});
gdjs.level0Code.eventsList92 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects7);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects7);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects7Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDplayerObjects7Objects, 96, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects7 */
/* Reuse gdjs.level0Code.GDplayerObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].rotateTowardPosition((( gdjs.level0Code.GDplayerObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects7[0].getCenterXInScene()), -((( gdjs.level0Code.GDplayerObjects7.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects7[0].getCenterYInScene())), 0, runtimeScene);
}
}}

}


};gdjs.level0Code.asyncCallback14765588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects7);

{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariables().getFromIndex(2), true);
}
}}
gdjs.level0Code.eventsList93 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.level0Code.GDmelee_9595weaponObjects6) asyncObjectsList.addObject("melee_weapon", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.level0Code.asyncCallback14765588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList94 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects6, gdjs.level0Code.GDmelee_9595weaponObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects7.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariableNumber(gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects7[k] = gdjs.level0Code.GDmelee_9595weaponObjects7[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects7 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].getBehavior("Animation").setAnimationName("combo01-1");
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects7.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects7[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects7[i].getVariables().getFromIndex(1)).add(1);
}
}
{ //Subevents
gdjs.level0Code.eventsList92(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDmelee_9595weaponObjects6 */
{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), false);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].rotateTowardAngle(0, 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{ //Subevents
gdjs.level0Code.eventsList93(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList95 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects5, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( !(gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);

{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setX((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setY((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getPointY("")));
}
}
{ //Subevents
gdjs.level0Code.eventsList89(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects5, gdjs.level0Code.GDenemy_9595meleeObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects6[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects6[k] = gdjs.level0Code.GDenemy_9595meleeObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDenemy_9595meleeObjects6 */
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);

{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setX((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getPointX("")) - 40);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects6.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects6[i].setY((( gdjs.level0Code.GDenemy_9595meleeObjects6.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects6[0].getPointY("")));
}
}
{ //Subevents
gdjs.level0Code.eventsList90(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(2), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList91(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects5, gdjs.level0Code.GDmelee_9595weaponObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects6.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects6[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects6[k] = gdjs.level0Code.GDmelee_9595weaponObjects6[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList94(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList96 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects4);

for (gdjs.level0Code.forEachIndex5 = 0;gdjs.level0Code.forEachIndex5 < gdjs.level0Code.GDmelee_9595weaponObjects4.length;++gdjs.level0Code.forEachIndex5) {
gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4, gdjs.level0Code.GDenemy_9595meleeObjects5);

gdjs.level0Code.GDmelee_9595weaponObjects5.length = 0;


gdjs.level0Code.forEachTemporary5 = gdjs.level0Code.GDmelee_9595weaponObjects4[gdjs.level0Code.forEachIndex5];
gdjs.level0Code.GDmelee_9595weaponObjects5.push(gdjs.level0Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariableString(gdjs.level0Code.GDmelee_9595weaponObjects5[i].getVariables().getFromIndex(0)) == "enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects5[0].getVariables()).getFromIndex(0)))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects5[k] = gdjs.level0Code.GDmelee_9595weaponObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.level0Code.eventsList95(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList97 = function(runtimeScene) {

{


gdjs.level0Code.eventsList88(runtimeScene);
}


{


gdjs.level0Code.eventsList96(runtimeScene);
}


};gdjs.level0Code.eventsList98 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects3, gdjs.level0Code.GDenemy_9595meleeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects4[i].getVariableNumber(gdjs.level0Code.GDenemy_9595meleeObjects4[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects4[k] = gdjs.level0Code.GDenemy_9595meleeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList97(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList99 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDenemy_9595meleeObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDenemy_9595meleeObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDenemy_9595meleeObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDenemy_9595meleeObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList98(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList100 = function(runtimeScene) {

{


gdjs.level0Code.eventsList80(runtimeScene);
}


{


gdjs.level0Code.eventsList87(runtimeScene);
}


{


gdjs.level0Code.eventsList99(runtimeScene);
}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgunObjects4Objects = Hashtable.newFrom({"gun": gdjs.level0Code.GDgunObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects4Objects = Hashtable.newFrom({"shadow": gdjs.level0Code.GDshadowObjects4});
gdjs.level0Code.eventsList101 = function(runtimeScene) {

};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects3Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects3Objects = Hashtable.newFrom({"shadow": gdjs.level0Code.GDshadowObjects3});
gdjs.level0Code.eventsList102 = function(runtimeScene) {

};gdjs.level0Code.eventsList103 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDenemyObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects4);
gdjs.level0Code.GDgunObjects4.length = 0;

gdjs.level0Code.GDshadowObjects4.length = 0;

gdjs.level0Code.GDenemyObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDenemyObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDenemyObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemyObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemyObjects4[i].getVariableBoolean(gdjs.level0Code.GDenemyObjects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemyObjects4[k] = gdjs.level0Code.GDenemyObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDenemyObjects4.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDenemyObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects4[i].setVariableBoolean(gdjs.level0Code.GDenemyObjects4[i].getVariables().getFromIndex(4), true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects4[i].returnVariable(gdjs.level0Code.GDenemyObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgunObjects4Objects, (( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getCenterXInScene()) - 32, (( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getCenterYInScene()) - 32, "");
}{for(var i = 0, len = gdjs.level0Code.GDenemyObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDenemyObjects4[i].setZOrder((( gdjs.level0Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects4[0].getZOrder()) - 2);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects4[i].returnVariable(gdjs.level0Code.GDgunObjects4[i].getVariables().getFromIndex(3)).setString("enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects4[0].getVariables()).getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects4[i].setZOrder((( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects4[i].getBehavior("Animation").setAnimationName("enemy01_gun");
}
}{for(var i = 0, len = gdjs.level0Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgunObjects4[i].getBehavior("FireBullet").SetCooldownOp(0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects4Objects, (( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getCenterXInScene()) - 24, (( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getCenterYInScene()) + 22, "");
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].returnVariable(gdjs.level0Code.GDshadowObjects4[i].getVariables().getFromIndex(0)).setString("enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemyObjects4[0].getVariables()).getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].setZOrder((( gdjs.level0Code.GDenemyObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDenemyObjects4[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].getBehavior("Resizable").setWidth(50);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects4[i].getBehavior("Resizable").setHeight(16);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDenemy_9595meleeObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);
gdjs.level0Code.GDmelee_9595weaponObjects3.length = 0;

gdjs.level0Code.GDshadowObjects3.length = 0;

gdjs.level0Code.GDenemy_9595meleeObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDenemy_9595meleeObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDenemy_9595meleeObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDenemy_9595meleeObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDenemy_9595meleeObjects3[k] = gdjs.level0Code.GDenemy_9595meleeObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDenemy_9595meleeObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects3[i].setVariableBoolean(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().getFromIndex(4), true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects3[i].returnVariable(gdjs.level0Code.GDenemy_9595meleeObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects3Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterXInScene()), (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.level0Code.GDenemy_9595meleeObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595meleeObjects3[i].setZOrder((( gdjs.level0Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDplayerObjects3[0].getZOrder()) - 2);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects3[i].returnVariable(gdjs.level0Code.GDmelee_9595weaponObjects3[i].getVariables().getFromIndex(0)).setString("enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects3[0].getVariables()).getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects3[i].setZOrder((( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDmelee_9595weaponObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDmelee_9595weaponObjects3[i].getBehavior("Animation").setAnimationName("player_sword_f");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDshadowObjects3Objects, (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterXInScene()) - 24, (( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getCenterYInScene()) + 22, "");
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects3[i].returnVariable(gdjs.level0Code.GDshadowObjects3[i].getVariables().getFromIndex(0)).setString("enemy_" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDenemy_9595meleeObjects3[0].getVariables()).getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects3[i].setZOrder((( gdjs.level0Code.GDenemy_9595meleeObjects3.length === 0 ) ? 0 :gdjs.level0Code.GDenemy_9595meleeObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects3[i].getBehavior("Resizable").setWidth(50);
}
}{for(var i = 0, len = gdjs.level0Code.GDshadowObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDshadowObjects3[i].getBehavior("Resizable").setHeight(16);
}
}}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects4, "sandbag": gdjs.level0Code.GDsandbagObjects4, "cover_box": gdjs.level0Code.GDcover_9595boxObjects4, "wall": gdjs.level0Code.GDwallObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects = Hashtable.newFrom({"melee_weapon": gdjs.level0Code.GDmelee_9595weaponObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects4, "sandbag": gdjs.level0Code.GDsandbagObjects4, "cover_box": gdjs.level0Code.GDcover_9595boxObjects4, "wall": gdjs.level0Code.GDwallObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects4, "sandbag": gdjs.level0Code.GDsandbagObjects4, "cover_box": gdjs.level0Code.GDcover_9595boxObjects4, "wall": gdjs.level0Code.GDwallObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects4, "sandbag": gdjs.level0Code.GDsandbagObjects4, "cover_box": gdjs.level0Code.GDcover_9595boxObjects4, "wall": gdjs.level0Code.GDwallObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.level0Code.GDbulletObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects3Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects3});
gdjs.level0Code.eventsList104 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDbulletObjects2, gdjs.level0Code.GDbulletObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects3[i].getBehavior("Animation").getAnimationName() != "green_bolt" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects3[k] = gdjs.level0Code.GDbulletObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects3[i].getBehavior("Animation").setAnimationName("green_bolt");
}
}}

}


{

/* Reuse gdjs.level0Code.GDbulletObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects2[i].getVariableString(gdjs.level0Code.GDbulletObjects2[i].getVariables().getFromIndex(0)) == "ricochet" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects2[k] = gdjs.level0Code.GDbulletObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects2[i].setColor("0;213;221");
}
}}

}


};gdjs.level0Code.eventsList105 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects3);
gdjs.level0Code.GDbarrelObjects3.length = 0;

gdjs.level0Code.GDcover_9595boxObjects3.length = 0;

gdjs.level0Code.GDsandbagObjects3.length = 0;

gdjs.level0Code.GDwallObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects3[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects3[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects3[k] = gdjs.level0Code.GDmelee_9595weaponObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.level0Code.GDbarrelObjects3_1final.length = 0;
gdjs.level0Code.GDcover_9595boxObjects3_1final.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects3_1final.length = 0;
gdjs.level0Code.GDsandbagObjects3_1final.length = 0;
gdjs.level0Code.GDwallObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects3, gdjs.level0Code.GDmelee_9595weaponObjects4);

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects4);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects, 96, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbarrelObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbarrelObjects3_1final.indexOf(gdjs.level0Code.GDbarrelObjects4[j]) === -1 )
            gdjs.level0Code.GDbarrelObjects3_1final.push(gdjs.level0Code.GDbarrelObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDcover_9595boxObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDcover_9595boxObjects3_1final.indexOf(gdjs.level0Code.GDcover_9595boxObjects4[j]) === -1 )
            gdjs.level0Code.GDcover_9595boxObjects3_1final.push(gdjs.level0Code.GDcover_9595boxObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDmelee_9595weaponObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDmelee_9595weaponObjects3_1final.indexOf(gdjs.level0Code.GDmelee_9595weaponObjects4[j]) === -1 )
            gdjs.level0Code.GDmelee_9595weaponObjects3_1final.push(gdjs.level0Code.GDmelee_9595weaponObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDsandbagObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDsandbagObjects3_1final.indexOf(gdjs.level0Code.GDsandbagObjects4[j]) === -1 )
            gdjs.level0Code.GDsandbagObjects3_1final.push(gdjs.level0Code.GDsandbagObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDwallObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDwallObjects3_1final.indexOf(gdjs.level0Code.GDwallObjects4[j]) === -1 )
            gdjs.level0Code.GDwallObjects3_1final.push(gdjs.level0Code.GDwallObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects3, gdjs.level0Code.GDmelee_9595weaponObjects4);

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDmelee_95959595weaponObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbarrelObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbarrelObjects3_1final.indexOf(gdjs.level0Code.GDbarrelObjects4[j]) === -1 )
            gdjs.level0Code.GDbarrelObjects3_1final.push(gdjs.level0Code.GDbarrelObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDcover_9595boxObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDcover_9595boxObjects3_1final.indexOf(gdjs.level0Code.GDcover_9595boxObjects4[j]) === -1 )
            gdjs.level0Code.GDcover_9595boxObjects3_1final.push(gdjs.level0Code.GDcover_9595boxObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDmelee_9595weaponObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDmelee_9595weaponObjects3_1final.indexOf(gdjs.level0Code.GDmelee_9595weaponObjects4[j]) === -1 )
            gdjs.level0Code.GDmelee_9595weaponObjects3_1final.push(gdjs.level0Code.GDmelee_9595weaponObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDsandbagObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDsandbagObjects3_1final.indexOf(gdjs.level0Code.GDsandbagObjects4[j]) === -1 )
            gdjs.level0Code.GDsandbagObjects3_1final.push(gdjs.level0Code.GDsandbagObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDwallObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDwallObjects3_1final.indexOf(gdjs.level0Code.GDwallObjects4[j]) === -1 )
            gdjs.level0Code.GDwallObjects3_1final.push(gdjs.level0Code.GDwallObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level0Code.GDbarrelObjects3_1final, gdjs.level0Code.GDbarrelObjects3);
gdjs.copyArray(gdjs.level0Code.GDcover_9595boxObjects3_1final, gdjs.level0Code.GDcover_9595boxObjects3);
gdjs.copyArray(gdjs.level0Code.GDmelee_9595weaponObjects3_1final, gdjs.level0Code.GDmelee_9595weaponObjects3);
gdjs.copyArray(gdjs.level0Code.GDsandbagObjects3_1final, gdjs.level0Code.GDsandbagObjects3);
gdjs.copyArray(gdjs.level0Code.GDwallObjects3_1final, gdjs.level0Code.GDwallObjects3);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects3 */
/* Reuse gdjs.level0Code.GDcover_9595boxObjects3 */
/* Reuse gdjs.level0Code.GDsandbagObjects3 */
/* Reuse gdjs.level0Code.GDwallObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].returnVariable(gdjs.level0Code.GDbarrelObjects3[i].getVariables().get("health")).sub(50);
}
for(var i = 0, len = gdjs.level0Code.GDsandbagObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects3[i].returnVariable(gdjs.level0Code.GDsandbagObjects3[i].getVariables().get("health")).sub(50);
}
for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects3[i].returnVariable(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().get("health")).sub(50);
}
for(var i = 0, len = gdjs.level0Code.GDwallObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDwallObjects3[i].returnVariable(gdjs.level0Code.GDwallObjects3[i].getVariables().get("health")).sub(50);
}
}}

}


{

gdjs.level0Code.GDbarrelObjects3.length = 0;

gdjs.level0Code.GDbulletObjects3.length = 0;

gdjs.level0Code.GDcover_9595boxObjects3.length = 0;

gdjs.level0Code.GDsandbagObjects3.length = 0;

gdjs.level0Code.GDwallObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.level0Code.GDbarrelObjects3_1final.length = 0;
gdjs.level0Code.GDbulletObjects3_1final.length = 0;
gdjs.level0Code.GDcover_9595boxObjects3_1final.length = 0;
gdjs.level0Code.GDsandbagObjects3_1final.length = 0;
gdjs.level0Code.GDwallObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects4);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects4);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects, 32, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbarrelObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbarrelObjects3_1final.indexOf(gdjs.level0Code.GDbarrelObjects4[j]) === -1 )
            gdjs.level0Code.GDbarrelObjects3_1final.push(gdjs.level0Code.GDbarrelObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDbulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbulletObjects3_1final.indexOf(gdjs.level0Code.GDbulletObjects4[j]) === -1 )
            gdjs.level0Code.GDbulletObjects3_1final.push(gdjs.level0Code.GDbulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDcover_9595boxObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDcover_9595boxObjects3_1final.indexOf(gdjs.level0Code.GDcover_9595boxObjects4[j]) === -1 )
            gdjs.level0Code.GDcover_9595boxObjects3_1final.push(gdjs.level0Code.GDcover_9595boxObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDsandbagObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDsandbagObjects3_1final.indexOf(gdjs.level0Code.GDsandbagObjects4[j]) === -1 )
            gdjs.level0Code.GDsandbagObjects3_1final.push(gdjs.level0Code.GDsandbagObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDwallObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDwallObjects3_1final.indexOf(gdjs.level0Code.GDwallObjects4[j]) === -1 )
            gdjs.level0Code.GDwallObjects3_1final.push(gdjs.level0Code.GDwallObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects4);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects4ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4ObjectsGDgdjs_9546level0Code_9546GDwallObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbarrelObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbarrelObjects3_1final.indexOf(gdjs.level0Code.GDbarrelObjects4[j]) === -1 )
            gdjs.level0Code.GDbarrelObjects3_1final.push(gdjs.level0Code.GDbarrelObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDbulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbulletObjects3_1final.indexOf(gdjs.level0Code.GDbulletObjects4[j]) === -1 )
            gdjs.level0Code.GDbulletObjects3_1final.push(gdjs.level0Code.GDbulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDcover_9595boxObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDcover_9595boxObjects3_1final.indexOf(gdjs.level0Code.GDcover_9595boxObjects4[j]) === -1 )
            gdjs.level0Code.GDcover_9595boxObjects3_1final.push(gdjs.level0Code.GDcover_9595boxObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDsandbagObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDsandbagObjects3_1final.indexOf(gdjs.level0Code.GDsandbagObjects4[j]) === -1 )
            gdjs.level0Code.GDsandbagObjects3_1final.push(gdjs.level0Code.GDsandbagObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDwallObjects4.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDwallObjects3_1final.indexOf(gdjs.level0Code.GDwallObjects4[j]) === -1 )
            gdjs.level0Code.GDwallObjects3_1final.push(gdjs.level0Code.GDwallObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level0Code.GDbarrelObjects3_1final, gdjs.level0Code.GDbarrelObjects3);
gdjs.copyArray(gdjs.level0Code.GDbulletObjects3_1final, gdjs.level0Code.GDbulletObjects3);
gdjs.copyArray(gdjs.level0Code.GDcover_9595boxObjects3_1final, gdjs.level0Code.GDcover_9595boxObjects3);
gdjs.copyArray(gdjs.level0Code.GDsandbagObjects3_1final, gdjs.level0Code.GDsandbagObjects3);
gdjs.copyArray(gdjs.level0Code.GDwallObjects3_1final, gdjs.level0Code.GDwallObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects3 */
/* Reuse gdjs.level0Code.GDbulletObjects3 */
/* Reuse gdjs.level0Code.GDcover_9595boxObjects3 */
/* Reuse gdjs.level0Code.GDsandbagObjects3 */
/* Reuse gdjs.level0Code.GDwallObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "bullet_on_object.wav", 7, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 7), gdjs.randomFloatInRange(0.85, 1));
}{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].returnVariable(gdjs.level0Code.GDbarrelObjects3[i].getVariables().get("health")).sub(10);
}
for(var i = 0, len = gdjs.level0Code.GDsandbagObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects3[i].returnVariable(gdjs.level0Code.GDsandbagObjects3[i].getVariables().get("health")).sub(10);
}
for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects3[i].returnVariable(gdjs.level0Code.GDcover_9595boxObjects3[i].getVariables().get("health")).sub(10);
}
for(var i = 0, len = gdjs.level0Code.GDwallObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDwallObjects3[i].returnVariable(gdjs.level0Code.GDwallObjects3[i].getVariables().get("health")).sub(10);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects3);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbulletObjects3Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects3Objects, 16, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "bullet_on_object.wav", 7, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 7), gdjs.randomFloatInRange(0.85, 1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects3[i].getVariableString(gdjs.level0Code.GDbulletObjects3[i].getVariables().getFromIndex(0)) == "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects3[k] = gdjs.level0Code.GDbulletObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects3[i].getBehavior("Animation").getAnimationName() != "red_bolt" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects3[k] = gdjs.level0Code.GDbulletObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbulletObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDbulletObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbulletObjects3[i].getBehavior("Animation").setAnimationName("red_bolt");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.level0Code.GDbulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbulletObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDbulletObjects2[i].getVariableString(gdjs.level0Code.GDbulletObjects2[i].getVariables().getFromIndex(0)) != "player" ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbulletObjects2[k] = gdjs.level0Code.GDbulletObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDbulletObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList104(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList106 = function(runtimeScene) {

};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.eventsList107 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDbarrelObjects4 */
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects4[i].returnVariable(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects4[0].getVariables()).getFromIndex(0))));
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4Objects = Hashtable.newFrom({"cover_box": gdjs.level0Code.GDcover_9595boxObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.eventsList108 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDcover_9595boxObjects4 */
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects4[i].returnVariable(gdjs.level0Code.GDcover_9595boxObjects4[i].getVariables().getFromIndex(0)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects4[0].getVariables()).getFromIndex(0))));
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects4Objects = Hashtable.newFrom({"sandbag": gdjs.level0Code.GDsandbagObjects4});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.eventsList109 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
/* Reuse gdjs.level0Code.GDsandbagObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDsandbagObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects4[i].returnVariable(gdjs.level0Code.GDsandbagObjects4[i].getVariables().getFromIndex(0)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDexplosionObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDexplosionObjects4[0].getVariables()).getFromIndex(0))));
}
}}

}


};gdjs.level0Code.eventsList110 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDexplosionObjects3, gdjs.level0Code.GDexplosionObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getBehavior("RepeatTimer").Repeat((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDexplosionObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDexplosionObjects4[i].toggleVariableBoolean(gdjs.level0Code.GDexplosionObjects4[i].getVariables().getFromIndex(1));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDexplosionObjects3, gdjs.level0Code.GDexplosionObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexplosionObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDexplosionObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDexplosionObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(gdjs.level0Code.GDexplosionObjects3, gdjs.level0Code.GDexplosionObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getVariableBoolean(gdjs.level0Code.GDexplosionObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList107(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(gdjs.level0Code.GDexplosionObjects3, gdjs.level0Code.GDexplosionObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getVariableBoolean(gdjs.level0Code.GDexplosionObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList108(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDexplosionObjects3, gdjs.level0Code.GDexplosionObjects4);

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects4Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, 96, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexplosionObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDexplosionObjects4[i].getVariableBoolean(gdjs.level0Code.GDexplosionObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexplosionObjects4[k] = gdjs.level0Code.GDexplosionObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDexplosionObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList109(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects5Objects = Hashtable.newFrom({"grenade": gdjs.level0Code.GDgrenadeObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects5ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects5Objects = Hashtable.newFrom({"enemy": gdjs.level0Code.GDenemyObjects5, "enemy_melee": gdjs.level0Code.GDenemy_9595meleeObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects5Objects = Hashtable.newFrom({"grenade": gdjs.level0Code.GDgrenadeObjects5});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects5ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects5ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects5ObjectsGDgdjs_9546level0Code_9546GDwallObjects5Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects5, "sandbag": gdjs.level0Code.GDsandbagObjects5, "cover_box": gdjs.level0Code.GDcover_9595boxObjects5, "wall": gdjs.level0Code.GDwallObjects5});
gdjs.level0Code.eventsList111 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects4, gdjs.level0Code.GDgrenadeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects5[i].getBehavior("Scale").getScale() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects5[k] = gdjs.level0Code.GDgrenadeObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects5[i].setColor("255;0;160");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects4, gdjs.level0Code.GDgrenadeObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects5[i].getBehavior("Scale").getScale() < 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects5[k] = gdjs.level0Code.GDgrenadeObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects5[i].getBehavior("Scale").setScale(gdjs.level0Code.GDgrenadeObjects5[i].getBehavior("Scale").getScale() + (0.007));
}
}}

}


{

/* Reuse gdjs.level0Code.GDgrenadeObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects4[i].getBehavior("Scale").getScale() >= 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects4[k] = gdjs.level0Code.GDgrenadeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects4[i].returnVariable(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.eventsList112 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 9));
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "explosion1.wav", 9, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 9), gdjs.randomFloatInRange(0.95, 1));
}}

}


};gdjs.level0Code.eventsList113 = function(runtimeScene) {

{

gdjs.level0Code.GDbarrelObjects4.length = 0;

gdjs.level0Code.GDcover_9595boxObjects4.length = 0;

gdjs.level0Code.GDenemyObjects4.length = 0;

gdjs.level0Code.GDenemy_9595meleeObjects4.length = 0;

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects4);

gdjs.level0Code.GDsandbagObjects4.length = 0;

gdjs.level0Code.GDwallObjects4.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.level0Code.GDbarrelObjects4_1final.length = 0;
gdjs.level0Code.GDcover_9595boxObjects4_1final.length = 0;
gdjs.level0Code.GDenemyObjects4_1final.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects4_1final.length = 0;
gdjs.level0Code.GDgrenadeObjects4_1final.length = 0;
gdjs.level0Code.GDsandbagObjects4_1final.length = 0;
gdjs.level0Code.GDwallObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("enemy"), gdjs.level0Code.GDenemyObjects5);
gdjs.copyArray(runtimeScene.getObjects("enemy_melee"), gdjs.level0Code.GDenemy_9595meleeObjects5);
gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects5Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDenemyObjects5ObjectsGDgdjs_9546level0Code_9546GDenemy_95959595meleeObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDenemyObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDenemyObjects4_1final.indexOf(gdjs.level0Code.GDenemyObjects5[j]) === -1 )
            gdjs.level0Code.GDenemyObjects4_1final.push(gdjs.level0Code.GDenemyObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDenemy_9595meleeObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDenemy_9595meleeObjects4_1final.indexOf(gdjs.level0Code.GDenemy_9595meleeObjects5[j]) === -1 )
            gdjs.level0Code.GDenemy_9595meleeObjects4_1final.push(gdjs.level0Code.GDenemy_9595meleeObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDgrenadeObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDgrenadeObjects4_1final.indexOf(gdjs.level0Code.GDgrenadeObjects5[j]) === -1 )
            gdjs.level0Code.GDgrenadeObjects4_1final.push(gdjs.level0Code.GDgrenadeObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects5);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects5);
gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects5);

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects5);
gdjs.copyArray(runtimeScene.getObjects("wall"), gdjs.level0Code.GDwallObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDgrenadeObjects5Objects, gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects5ObjectsGDgdjs_9546level0Code_9546GDsandbagObjects5ObjectsGDgdjs_9546level0Code_9546GDcover_95959595boxObjects5ObjectsGDgdjs_9546level0Code_9546GDwallObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDbarrelObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDbarrelObjects4_1final.indexOf(gdjs.level0Code.GDbarrelObjects5[j]) === -1 )
            gdjs.level0Code.GDbarrelObjects4_1final.push(gdjs.level0Code.GDbarrelObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDcover_9595boxObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDcover_9595boxObjects4_1final.indexOf(gdjs.level0Code.GDcover_9595boxObjects5[j]) === -1 )
            gdjs.level0Code.GDcover_9595boxObjects4_1final.push(gdjs.level0Code.GDcover_9595boxObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDgrenadeObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDgrenadeObjects4_1final.indexOf(gdjs.level0Code.GDgrenadeObjects5[j]) === -1 )
            gdjs.level0Code.GDgrenadeObjects4_1final.push(gdjs.level0Code.GDgrenadeObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDsandbagObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDsandbagObjects4_1final.indexOf(gdjs.level0Code.GDsandbagObjects5[j]) === -1 )
            gdjs.level0Code.GDsandbagObjects4_1final.push(gdjs.level0Code.GDsandbagObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.level0Code.GDwallObjects5.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDwallObjects4_1final.indexOf(gdjs.level0Code.GDwallObjects5[j]) === -1 )
            gdjs.level0Code.GDwallObjects4_1final.push(gdjs.level0Code.GDwallObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level0Code.GDbarrelObjects4_1final, gdjs.level0Code.GDbarrelObjects4);
gdjs.copyArray(gdjs.level0Code.GDcover_9595boxObjects4_1final, gdjs.level0Code.GDcover_9595boxObjects4);
gdjs.copyArray(gdjs.level0Code.GDenemyObjects4_1final, gdjs.level0Code.GDenemyObjects4);
gdjs.copyArray(gdjs.level0Code.GDenemy_9595meleeObjects4_1final, gdjs.level0Code.GDenemy_9595meleeObjects4);
gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects4_1final, gdjs.level0Code.GDgrenadeObjects4);
gdjs.copyArray(gdjs.level0Code.GDsandbagObjects4_1final, gdjs.level0Code.GDsandbagObjects4);
gdjs.copyArray(gdjs.level0Code.GDwallObjects4_1final, gdjs.level0Code.GDwallObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects4[i].clearForces();
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects4[i].getVariableNumber(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects4[k] = gdjs.level0Code.GDgrenadeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects4[i].getVariableNumber(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)) < (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects4[k] = gdjs.level0Code.GDgrenadeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList111(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects4[i].getVariableNumber(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects4[k] = gdjs.level0Code.GDgrenadeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects4[i].returnVariable(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDgrenadeObjects3, gdjs.level0Code.GDgrenadeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDgrenadeObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDgrenadeObjects4[i].getVariableNumber(gdjs.level0Code.GDgrenadeObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDgrenadeObjects4[k] = gdjs.level0Code.GDgrenadeObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDgrenadeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDgrenadeObjects4 */
gdjs.level0Code.GDexplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, (( gdjs.level0Code.GDgrenadeObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDgrenadeObjects4[0].getCenterXInScene()) - 48, (( gdjs.level0Code.GDgrenadeObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDgrenadeObjects4[0].getCenterYInScene()) - 48, "");
}{for(var i = 0, len = gdjs.level0Code.GDgrenadeObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDgrenadeObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.level0Code.eventsList112(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList114 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("grenade"), gdjs.level0Code.GDgrenadeObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDgrenadeObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDgrenadeObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDgrenadeObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDgrenadeObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList113(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects3Objects = Hashtable.newFrom({"barrel": gdjs.level0Code.GDbarrelObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects3Objects = Hashtable.newFrom({"cover_box": gdjs.level0Code.GDcover_9595boxObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects3Objects = Hashtable.newFrom({"sandbag": gdjs.level0Code.GDsandbagObjects3});
gdjs.level0Code.eventsList115 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDbarrelObjects4, gdjs.level0Code.GDbarrelObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects5[i].getBehavior("Scale").getScale() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects5[k] = gdjs.level0Code.GDbarrelObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects5[i].setColor("255;0;160");
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbarrelObjects4, gdjs.level0Code.GDbarrelObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects5[i].getBehavior("Scale").getScale() < 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects5[k] = gdjs.level0Code.GDbarrelObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects5[i].getBehavior("Scale").setScale(gdjs.level0Code.GDbarrelObjects5[i].getBehavior("Scale").getScale() + (0.01));
}
}}

}


{

/* Reuse gdjs.level0Code.GDbarrelObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects4[i].getBehavior("Scale").getScale() >= 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects4[k] = gdjs.level0Code.GDbarrelObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects4[i].returnVariable(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects = Hashtable.newFrom({"explosion": gdjs.level0Code.GDexplosionObjects4});
gdjs.level0Code.eventsList116 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 9));
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "explosion1.wav", 9, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 9), gdjs.randomFloatInRange(0.95, 1));
}}

}


};gdjs.level0Code.eventsList117 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDbarrelObjects3, gdjs.level0Code.GDbarrelObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects4[i].getVariableNumber(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects4[k] = gdjs.level0Code.GDbarrelObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects4[i].getVariableNumber(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)) < (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects4[k] = gdjs.level0Code.GDbarrelObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList115(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.level0Code.GDbarrelObjects3, gdjs.level0Code.GDbarrelObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects4[i].getVariableNumber(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects4[k] = gdjs.level0Code.GDbarrelObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects4[i].returnVariable(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDbarrelObjects3, gdjs.level0Code.GDbarrelObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbarrelObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDbarrelObjects4[i].getVariableNumber(gdjs.level0Code.GDbarrelObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbarrelObjects4[k] = gdjs.level0Code.GDbarrelObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDbarrelObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDbarrelObjects4 */
gdjs.level0Code.GDexplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDexplosionObjects4Objects, (( gdjs.level0Code.GDbarrelObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDbarrelObjects4[0].getCenterXInScene()) - 48, (( gdjs.level0Code.GDbarrelObjects4.length === 0 ) ? 0 :gdjs.level0Code.GDbarrelObjects4[0].getCenterYInScene()) - 48, "");
}{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.level0Code.eventsList116(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList118 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects3);
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDbarrelObjects3Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects3);
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects3);
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects3Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects3);
gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects3);
{for(var i = 0, len = gdjs.level0Code.GDbarrelObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbarrelObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("barrel"), gdjs.level0Code.GDbarrelObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDbarrelObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDbarrelObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDbarrelObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDbarrelObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList117(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects3Objects = Hashtable.newFrom({"cover_box": gdjs.level0Code.GDcover_9595boxObjects3});
gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects3Objects = Hashtable.newFrom({"sandbag": gdjs.level0Code.GDsandbagObjects3});
gdjs.level0Code.eventsList119 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDcover_9595boxObjects3, gdjs.level0Code.GDcover_9595boxObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDcover_9595boxObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDcover_9595boxObjects4[i].getVariableNumber(gdjs.level0Code.GDcover_9595boxObjects4[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDcover_9595boxObjects4[k] = gdjs.level0Code.GDcover_9595boxObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDcover_9595boxObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDcover_9595boxObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects4[i].returnVariable(gdjs.level0Code.GDcover_9595boxObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDcover_9595boxObjects3, gdjs.level0Code.GDcover_9595boxObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDcover_9595boxObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDcover_9595boxObjects4[i].getVariableNumber(gdjs.level0Code.GDcover_9595boxObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDcover_9595boxObjects4[k] = gdjs.level0Code.GDcover_9595boxObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDcover_9595boxObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDcover_9595boxObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level0Code.eventsList120 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects3);
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDcover_95959595boxObjects3Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects3);
gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects3);
{for(var i = 0, len = gdjs.level0Code.GDcover_9595boxObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDcover_9595boxObjects3[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects3Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cover_box"), gdjs.level0Code.GDcover_9595boxObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDcover_9595boxObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDcover_9595boxObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDcover_9595boxObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDcover_9595boxObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList119(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects2Objects = Hashtable.newFrom({"sandbag": gdjs.level0Code.GDsandbagObjects2});
gdjs.level0Code.eventsList121 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDsandbagObjects2, gdjs.level0Code.GDsandbagObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDsandbagObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDsandbagObjects3[i].getVariableNumber(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDsandbagObjects3[k] = gdjs.level0Code.GDsandbagObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDsandbagObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDsandbagObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDsandbagObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects3[i].returnVariable(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDsandbagObjects2, gdjs.level0Code.GDsandbagObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDsandbagObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDsandbagObjects3[i].getVariableNumber(gdjs.level0Code.GDsandbagObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDsandbagObjects3[k] = gdjs.level0Code.GDsandbagObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDsandbagObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDsandbagObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDsandbagObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level0Code.eventsList122 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects2);
{for(var i = 0, len = gdjs.level0Code.GDsandbagObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDsandbagObjects2[i].separateFromObjectsList(gdjs.level0Code.mapOfGDgdjs_9546level0Code_9546GDsandbagObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sandbag"), gdjs.level0Code.GDsandbagObjects1);

for (gdjs.level0Code.forEachIndex2 = 0;gdjs.level0Code.forEachIndex2 < gdjs.level0Code.GDsandbagObjects1.length;++gdjs.level0Code.forEachIndex2) {
gdjs.level0Code.GDsandbagObjects2.length = 0;


gdjs.level0Code.forEachTemporary2 = gdjs.level0Code.GDsandbagObjects1[gdjs.level0Code.forEachIndex2];
gdjs.level0Code.GDsandbagObjects2.push(gdjs.level0Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList121(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList123 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("blood"), gdjs.level0Code.GDbloodObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDbloodObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDbloodObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDbloodObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDbloodObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDbloodObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDbloodObjects3[i].getZOrder() != 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDbloodObjects3[k] = gdjs.level0Code.GDbloodObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDbloodObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.level0Code.GDbloodObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDbloodObjects3[i].setZOrder(1);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("explosion"), gdjs.level0Code.GDexplosionObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDexplosionObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDexplosionObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDexplosionObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDexplosionObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList110(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.level0Code.eventsList114(runtimeScene);
}


{


gdjs.level0Code.eventsList118(runtimeScene);
}


{


gdjs.level0Code.eventsList120(runtimeScene);
}


{


gdjs.level0Code.eventsList122(runtimeScene);
}


};gdjs.level0Code.eventsList124 = function(runtimeScene) {

{


gdjs.level0Code.eventsList64(runtimeScene);
}


{


gdjs.level0Code.eventsList100(runtimeScene);
}


{


gdjs.level0Code.eventsList103(runtimeScene);
}


{


gdjs.level0Code.eventsList105(runtimeScene);
}


{


gdjs.level0Code.eventsList123(runtimeScene);
}


};gdjs.level0Code.eventsList125 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), false);
}}

}


};gdjs.level0Code.eventsList126 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].SetLabelText("50% Health Upgrade", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), true);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].SetLabelText("Tri-beam Shot Upgrade", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), true);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].SetLabelText("20% Rage Retention", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setVariableBoolean(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(1), true);
}
}}

}


};gdjs.level0Code.eventsList127 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getX() != -(2976) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setX(-(2976));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getY() != -(2912) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setY(-(2912));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getY() != -(2848) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setY(-(2848));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].getY() != -(2784) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4[i].setY(-(2784));
}
}}

}


};gdjs.level0Code.eventsList128 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(21), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(21), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu"), gdjs.level0Code.GDupgrade_9595menuObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menuObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menuObjects3[i].getX() != -(3008) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menuObjects3[k] = gdjs.level0Code.GDupgrade_9595menuObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menuObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menuObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menuObjects3[i].getY() != -(3008) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menuObjects3[k] = gdjs.level0Code.GDupgrade_9595menuObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menuObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menuObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menuObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menuObjects3[i].setPosition(-(3008),-(3008));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_text"), gdjs.level0Code.GDupgrade_9595menu_9595textObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].getX() != -(3008) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[k] = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].getY() != -(2976) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[k] = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595textObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].setPosition(-(3008),-(2976));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_button"), gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList127(runtimeScene);} //Subevents end.
}
}

}


};gdjs.level0Code.eventsList129 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getX() != 512 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].setX(512);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getY() != 288 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].setY(288);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getY() != 352 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].setY(352);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].getY() != 416 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5[i].setY(416);
}
}}

}


};gdjs.level0Code.eventsList130 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_button"), gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3);

for (gdjs.level0Code.forEachIndex4 = 0;gdjs.level0Code.forEachIndex4 < gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.length;++gdjs.level0Code.forEachIndex4) {
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = 0;


gdjs.level0Code.forEachTemporary4 = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3[gdjs.level0Code.forEachIndex4];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.push(gdjs.level0Code.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList129(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.level0Code.asyncCallback14824348 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.level0Code.eventsList130(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.level0Code.eventsList131 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.level0Code.asyncCallback14824348(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList132 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(21), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].setVariableBoolean(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(21), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu"), gdjs.level0Code.GDupgrade_9595menuObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menuObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menuObjects3[i].getX() != 480 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menuObjects3[k] = gdjs.level0Code.GDupgrade_9595menuObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menuObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menuObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menuObjects3[i].getY() != 192 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menuObjects3[k] = gdjs.level0Code.GDupgrade_9595menuObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menuObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menuObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menuObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menuObjects3[i].setPosition(480,192);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_text"), gdjs.level0Code.GDupgrade_9595menu_9595textObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].getX() != 480 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[k] = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].getY() != 224 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[k] = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595textObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].setPosition(480,224);
}
}{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595textObjects3[i].setString("UPGRADES");
}
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.level0Code.eventsList131(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList133 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects1, gdjs.level0Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects2[i].returnVariable(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(8)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(8))) + (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(8))) * 0.5);
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects2[i].returnVariable(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(8))));
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects1, gdjs.level0Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects2[i].returnVariable(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(11)).setNumber(3);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1, gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariableNumber(gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.level0Code.GDplayerObjects1, gdjs.level0Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.level0Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects2[i].returnVariable(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(20)).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(20))) - (gdjs.RuntimeObject.getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(20))) * 0.2);
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
}}

}


};gdjs.level0Code.eventsList134 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(17), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList125(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_button"), gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2);

for (gdjs.level0Code.forEachIndex3 = 0;gdjs.level0Code.forEachIndex3 < gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length;++gdjs.level0Code.forEachIndex3) {
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.length = 0;


gdjs.level0Code.forEachTemporary3 = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2[gdjs.level0Code.forEachIndex3];
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.push(gdjs.level0Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.level0Code.eventsList126(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList128(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList132(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("upgrade_menu_button"), gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i].IsActivated((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[k] = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects1);
/* Reuse gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1 */
{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1[i].SetLabelText("", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects1[i].returnVariable(gdjs.level0Code.GDplayerObjects1[i].getVariables().getFromIndex(1)).add(20);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "menu_select.wav", 10, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 10), gdjs.randomInRange(0.98, 1));
}
{ //Subevents
gdjs.level0Code.eventsList133(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList135 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) != gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit_text"), gdjs.level0Code.GDexit_9595textObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects2[i].getX() != -(3008) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects2[k] = gdjs.level0Code.GDexit_9595textObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects2[i].getY() != -(2976) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects2[k] = gdjs.level0Code.GDexit_9595textObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexit_9595textObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDexit_9595textObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDexit_9595textObjects2[i].setPosition(-(3008),-(2976));
}
}}

}


};gdjs.level0Code.eventsList136 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).sub(0.01);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)) <= 0.05;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main_menu", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit_text"), gdjs.level0Code.GDexit_9595textObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects2[i].getX() != 480 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects2[k] = gdjs.level0Code.GDexit_9595textObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDexit_9595textObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDexit_9595textObjects2[i].getY() != 128 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDexit_9595textObjects2[k] = gdjs.level0Code.GDexit_9595textObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDexit_9595textObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDexit_9595textObjects2 */
{for(var i = 0, len = gdjs.level0Code.GDexit_9595textObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDexit_9595textObjects2[i].setPosition(480,128);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("exit_text"), gdjs.level0Code.GDexit_9595textObjects1);
{for(var i = 0, len = gdjs.level0Code.GDexit_9595textObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDexit_9595textObjects1[i].setString("LEAVING IN " + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10)))) + "\nPress Escape Again to Cancel");
}
}}

}


};gdjs.level0Code.eventsList137 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(9));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(9), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList135(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList136(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList138 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects1[i].getVariableNumber(gdjs.level0Code.GDplayerObjects1[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects1[k] = gdjs.level0Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList137(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList139 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("armor"), gdjs.level0Code.GDarmorObjects2);
gdjs.copyArray(runtimeScene.getObjects("health_bar"), gdjs.level0Code.GDhealth_9595barObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("rage"), gdjs.level0Code.GDrageObjects2);
{for(var i = 0, len = gdjs.level0Code.GDhealth_9595barObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDhealth_9595barObjects2[i].SetValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects2[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDarmorObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDarmorObjects2[i].SetValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level0Code.GDrageObjects2.length ;i < len;++i) {
    gdjs.level0Code.GDrageObjects2[i].SetValue((gdjs.RuntimeObject.getVariableNumber(((gdjs.level0Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level0Code.GDplayerObjects2[0].getVariables()).getFromIndex(16))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.level0Code.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("waves_debug"), gdjs.level0Code.GDwaves_9595debugObjects1);
{for(var i = 0, len = gdjs.level0Code.GDdebugObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDdebugObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))) + " Enemies Alive");
}
}{for(var i = 0, len = gdjs.level0Code.GDwaves_9595debugObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDwaves_9595debugObjects1[i].setString("Wave " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))) + " out of " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.level0Code.eventsList140 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 0, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 2, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 3, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 4, 0);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 5, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 6, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 7, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 8, 5);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 9, 5);
}}

}


};gdjs.level0Code.asyncCallback14844924 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.level0Code.eventsList140(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.level0Code.eventsList141 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.level0Code.asyncCallback14844924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList142 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 0, 50);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, 50);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 2, 20);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 3, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 4, 30);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 5, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 6, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 7, 60);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 8, 0);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 9, 70);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 10, 50);
}}

}


};gdjs.level0Code.asyncCallback14848932 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.level0Code.eventsList142(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.level0Code.eventsList143 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.level0Code.asyncCallback14848932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level0Code.eventsList144 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(15)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(15)) < 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "gun1burst.wav", 0, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 0), gdjs.evtTools.sound.getSoundOnChannelPitch(runtimeScene, 0));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "gun1burst.wav", 0, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 0), gdjs.evtTools.sound.getSoundOnChannelPitch(runtimeScene, 0));
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.level0Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects3[i].returnVariable(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(15)).setNumber(0);
}
}}

}


};gdjs.level0Code.eventsList145 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableBoolean(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(21), false) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(15)) < 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level0Code.GDplayerObjects4 */
{for(var i = 0, len = gdjs.level0Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level0Code.GDplayerObjects4[i].returnVariable(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(15)).add(0.01);
}
}}

}


{

gdjs.copyArray(gdjs.level0Code.GDplayerObjects3, gdjs.level0Code.GDplayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects4[i].getVariableNumber(gdjs.level0Code.GDplayerObjects4[i].getVariables().getFromIndex(15)) >= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects4[k] = gdjs.level0Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "gun3burst.wav", 1, true, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 1), gdjs.evtTools.sound.getSoundOnChannelPitch(runtimeScene, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList144(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList146 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList145(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList147 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("melee_weapon"), gdjs.level0Code.GDmelee_9595weaponObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 0));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDmelee_9595weaponObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDmelee_9595weaponObjects3[i].getVariableBoolean(gdjs.level0Code.GDmelee_9595weaponObjects3[i].getVariables().getFromIndex(3), true) ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDmelee_9595weaponObjects3[k] = gdjs.level0Code.GDmelee_9595weaponObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDmelee_9595weaponObjects3.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sword.wav", 0, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 0), gdjs.evtTools.sound.getSoundOnChannelPitch(runtimeScene, 0));
}}

}


};gdjs.level0Code.eventsList148 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList147(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList149 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects2[i].getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(5)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects2[k] = gdjs.level0Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 5));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sword.wav", 5, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 5), gdjs.randomFloatInRange(0.85, 1));
}}

}


};gdjs.level0Code.eventsList150 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(4)) != 0 ) {
        isConditionTrue_0 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 4));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "player_hit.wav", 4, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 4), gdjs.randomFloatInRange(0.85, 1));
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "bullet_on_object.wav", 7, false, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 7), gdjs.randomFloatInRange(0.85, 1));
}}

}


{


gdjs.level0Code.eventsList146(runtimeScene);
}


{


gdjs.level0Code.eventsList148(runtimeScene);
}


{


gdjs.level0Code.eventsList149(runtimeScene);
}


};gdjs.level0Code.eventsList151 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.level0Code.eventsList150(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList152 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 0, 50);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, 50);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 2, 20);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 3, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 4, 30);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 5, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 6, 40);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 7, 60);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 8, 0);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 9, 70);
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 10, 50);
}}

}


};gdjs.level0Code.eventsList153 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(16), true);
}
{ //Subevents
gdjs.level0Code.eventsList152(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList154 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects2[i].getVariableNumber(gdjs.level0Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDplayerObjects2[k] = gdjs.level0Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), false);
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), true);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), false);
}}

}


{

gdjs.level0Code.GDplayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.level0Code.GDplayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level0Code.GDplayerObjects3);
for (var i = 0, k = 0, l = gdjs.level0Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.level0Code.GDplayerObjects3[i].getVariableNumber(gdjs.level0Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.level0Code.GDplayerObjects3[k] = gdjs.level0Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.level0Code.GDplayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.level0Code.GDplayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.level0Code.GDplayerObjects2_1final.indexOf(gdjs.level0Code.GDplayerObjects3[j]) === -1 )
            gdjs.level0Code.GDplayerObjects2_1final.push(gdjs.level0Code.GDplayerObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(12), true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.level0Code.GDplayerObjects2_1final, gdjs.level0Code.GDplayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), true);
}
{ //Subevents
gdjs.level0Code.eventsList141(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(14), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), true);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false);
}
{ //Subevents
gdjs.level0Code.eventsList143(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 0);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setSoundOnChannelPitch(runtimeScene, 0, gdjs.randomFloatInRange(0.85, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setSoundOnChannelPitch(runtimeScene, 1, gdjs.randomFloatInRange(0.95, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 3);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setSoundOnChannelPitch(runtimeScene, 3, gdjs.randomFloatInRange(0.95, 1));
}}

}


{


gdjs.level0Code.eventsList151(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(16), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.level0Code.eventsList153(runtimeScene);} //End of subevents
}

}


};gdjs.level0Code.eventsList155 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelVolume(runtimeScene, 12) != 60;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 12, 60);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelVolume(runtimeScene, 12) != 0;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 12, 0);
}}

}


};gdjs.level0Code.eventsList156 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("death_message"), gdjs.level0Code.GDdeath_9595messageObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemy_spawner"), gdjs.level0Code.GDenemy_9595spawnerObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)));
}{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)));
}{for(var i = 0, len = gdjs.level0Code.GDdeath_9595messageObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDdeath_9595messageObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level0Code.GDenemy_9595spawnerObjects1.length ;i < len;++i) {
    gdjs.level0Code.GDenemy_9595spawnerObjects1[i].hide();
}
}
{ //Subevents
gdjs.level0Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.level0Code.eventsList19(runtimeScene);
}


{


gdjs.level0Code.eventsList124(runtimeScene);
}


{


gdjs.level0Code.eventsList134(runtimeScene);
}


{


gdjs.level0Code.eventsList138(runtimeScene);
}


{


gdjs.level0Code.eventsList139(runtimeScene);
}


{


gdjs.level0Code.eventsList154(runtimeScene);
}


{


gdjs.level0Code.eventsList155(runtimeScene);
}


};

gdjs.level0Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level0Code.GDplayerObjects1.length = 0;
gdjs.level0Code.GDplayerObjects2.length = 0;
gdjs.level0Code.GDplayerObjects3.length = 0;
gdjs.level0Code.GDplayerObjects4.length = 0;
gdjs.level0Code.GDplayerObjects5.length = 0;
gdjs.level0Code.GDplayerObjects6.length = 0;
gdjs.level0Code.GDplayerObjects7.length = 0;
gdjs.level0Code.GDplayerObjects8.length = 0;
gdjs.level0Code.GDplayerObjects9.length = 0;
gdjs.level0Code.GDfloor0Objects1.length = 0;
gdjs.level0Code.GDfloor0Objects2.length = 0;
gdjs.level0Code.GDfloor0Objects3.length = 0;
gdjs.level0Code.GDfloor0Objects4.length = 0;
gdjs.level0Code.GDfloor0Objects5.length = 0;
gdjs.level0Code.GDfloor0Objects6.length = 0;
gdjs.level0Code.GDfloor0Objects7.length = 0;
gdjs.level0Code.GDfloor0Objects8.length = 0;
gdjs.level0Code.GDfloor0Objects9.length = 0;
gdjs.level0Code.GDgunObjects1.length = 0;
gdjs.level0Code.GDgunObjects2.length = 0;
gdjs.level0Code.GDgunObjects3.length = 0;
gdjs.level0Code.GDgunObjects4.length = 0;
gdjs.level0Code.GDgunObjects5.length = 0;
gdjs.level0Code.GDgunObjects6.length = 0;
gdjs.level0Code.GDgunObjects7.length = 0;
gdjs.level0Code.GDgunObjects8.length = 0;
gdjs.level0Code.GDgunObjects9.length = 0;
gdjs.level0Code.GDdebugObjects1.length = 0;
gdjs.level0Code.GDdebugObjects2.length = 0;
gdjs.level0Code.GDdebugObjects3.length = 0;
gdjs.level0Code.GDdebugObjects4.length = 0;
gdjs.level0Code.GDdebugObjects5.length = 0;
gdjs.level0Code.GDdebugObjects6.length = 0;
gdjs.level0Code.GDdebugObjects7.length = 0;
gdjs.level0Code.GDdebugObjects8.length = 0;
gdjs.level0Code.GDdebugObjects9.length = 0;
gdjs.level0Code.GDbulletObjects1.length = 0;
gdjs.level0Code.GDbulletObjects2.length = 0;
gdjs.level0Code.GDbulletObjects3.length = 0;
gdjs.level0Code.GDbulletObjects4.length = 0;
gdjs.level0Code.GDbulletObjects5.length = 0;
gdjs.level0Code.GDbulletObjects6.length = 0;
gdjs.level0Code.GDbulletObjects7.length = 0;
gdjs.level0Code.GDbulletObjects8.length = 0;
gdjs.level0Code.GDbulletObjects9.length = 0;
gdjs.level0Code.GDbarrelObjects1.length = 0;
gdjs.level0Code.GDbarrelObjects2.length = 0;
gdjs.level0Code.GDbarrelObjects3.length = 0;
gdjs.level0Code.GDbarrelObjects4.length = 0;
gdjs.level0Code.GDbarrelObjects5.length = 0;
gdjs.level0Code.GDbarrelObjects6.length = 0;
gdjs.level0Code.GDbarrelObjects7.length = 0;
gdjs.level0Code.GDbarrelObjects8.length = 0;
gdjs.level0Code.GDbarrelObjects9.length = 0;
gdjs.level0Code.GDcover_9595boxObjects1.length = 0;
gdjs.level0Code.GDcover_9595boxObjects2.length = 0;
gdjs.level0Code.GDcover_9595boxObjects3.length = 0;
gdjs.level0Code.GDcover_9595boxObjects4.length = 0;
gdjs.level0Code.GDcover_9595boxObjects5.length = 0;
gdjs.level0Code.GDcover_9595boxObjects6.length = 0;
gdjs.level0Code.GDcover_9595boxObjects7.length = 0;
gdjs.level0Code.GDcover_9595boxObjects8.length = 0;
gdjs.level0Code.GDcover_9595boxObjects9.length = 0;
gdjs.level0Code.GDsandbagObjects1.length = 0;
gdjs.level0Code.GDsandbagObjects2.length = 0;
gdjs.level0Code.GDsandbagObjects3.length = 0;
gdjs.level0Code.GDsandbagObjects4.length = 0;
gdjs.level0Code.GDsandbagObjects5.length = 0;
gdjs.level0Code.GDsandbagObjects6.length = 0;
gdjs.level0Code.GDsandbagObjects7.length = 0;
gdjs.level0Code.GDsandbagObjects8.length = 0;
gdjs.level0Code.GDsandbagObjects9.length = 0;
gdjs.level0Code.GDenemyObjects1.length = 0;
gdjs.level0Code.GDenemyObjects2.length = 0;
gdjs.level0Code.GDenemyObjects3.length = 0;
gdjs.level0Code.GDenemyObjects4.length = 0;
gdjs.level0Code.GDenemyObjects5.length = 0;
gdjs.level0Code.GDenemyObjects6.length = 0;
gdjs.level0Code.GDenemyObjects7.length = 0;
gdjs.level0Code.GDenemyObjects8.length = 0;
gdjs.level0Code.GDenemyObjects9.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects1.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects2.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects3.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects4.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects5.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects6.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects7.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects8.length = 0;
gdjs.level0Code.GDenemy_9595meleeObjects9.length = 0;
gdjs.level0Code.GDhealth_9595barObjects1.length = 0;
gdjs.level0Code.GDhealth_9595barObjects2.length = 0;
gdjs.level0Code.GDhealth_9595barObjects3.length = 0;
gdjs.level0Code.GDhealth_9595barObjects4.length = 0;
gdjs.level0Code.GDhealth_9595barObjects5.length = 0;
gdjs.level0Code.GDhealth_9595barObjects6.length = 0;
gdjs.level0Code.GDhealth_9595barObjects7.length = 0;
gdjs.level0Code.GDhealth_9595barObjects8.length = 0;
gdjs.level0Code.GDhealth_9595barObjects9.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects1.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects2.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects3.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects4.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects5.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects6.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects7.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects8.length = 0;
gdjs.level0Code.GDhealth_9595kitObjects9.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects1.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects2.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects3.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects4.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects5.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects6.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects7.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects8.length = 0;
gdjs.level0Code.GDmelee_9595weaponObjects9.length = 0;
gdjs.level0Code.GDbloodObjects1.length = 0;
gdjs.level0Code.GDbloodObjects2.length = 0;
gdjs.level0Code.GDbloodObjects3.length = 0;
gdjs.level0Code.GDbloodObjects4.length = 0;
gdjs.level0Code.GDbloodObjects5.length = 0;
gdjs.level0Code.GDbloodObjects6.length = 0;
gdjs.level0Code.GDbloodObjects7.length = 0;
gdjs.level0Code.GDbloodObjects8.length = 0;
gdjs.level0Code.GDbloodObjects9.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects1.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects2.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects3.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects4.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects5.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects6.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects7.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects8.length = 0;
gdjs.level0Code.GDwaves_9595debugObjects9.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects1.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects2.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects3.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects4.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects5.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects6.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects7.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects8.length = 0;
gdjs.level0Code.GDenemy_9595spawnerObjects9.length = 0;
gdjs.level0Code.GDwave_9595timerObjects1.length = 0;
gdjs.level0Code.GDwave_9595timerObjects2.length = 0;
gdjs.level0Code.GDwave_9595timerObjects3.length = 0;
gdjs.level0Code.GDwave_9595timerObjects4.length = 0;
gdjs.level0Code.GDwave_9595timerObjects5.length = 0;
gdjs.level0Code.GDwave_9595timerObjects6.length = 0;
gdjs.level0Code.GDwave_9595timerObjects7.length = 0;
gdjs.level0Code.GDwave_9595timerObjects8.length = 0;
gdjs.level0Code.GDwave_9595timerObjects9.length = 0;
gdjs.level0Code.GDHUDObjects1.length = 0;
gdjs.level0Code.GDHUDObjects2.length = 0;
gdjs.level0Code.GDHUDObjects3.length = 0;
gdjs.level0Code.GDHUDObjects4.length = 0;
gdjs.level0Code.GDHUDObjects5.length = 0;
gdjs.level0Code.GDHUDObjects6.length = 0;
gdjs.level0Code.GDHUDObjects7.length = 0;
gdjs.level0Code.GDHUDObjects8.length = 0;
gdjs.level0Code.GDHUDObjects9.length = 0;
gdjs.level0Code.GDarmorObjects1.length = 0;
gdjs.level0Code.GDarmorObjects2.length = 0;
gdjs.level0Code.GDarmorObjects3.length = 0;
gdjs.level0Code.GDarmorObjects4.length = 0;
gdjs.level0Code.GDarmorObjects5.length = 0;
gdjs.level0Code.GDarmorObjects6.length = 0;
gdjs.level0Code.GDarmorObjects7.length = 0;
gdjs.level0Code.GDarmorObjects8.length = 0;
gdjs.level0Code.GDarmorObjects9.length = 0;
gdjs.level0Code.GDgrenadesObjects1.length = 0;
gdjs.level0Code.GDgrenadesObjects2.length = 0;
gdjs.level0Code.GDgrenadesObjects3.length = 0;
gdjs.level0Code.GDgrenadesObjects4.length = 0;
gdjs.level0Code.GDgrenadesObjects5.length = 0;
gdjs.level0Code.GDgrenadesObjects6.length = 0;
gdjs.level0Code.GDgrenadesObjects7.length = 0;
gdjs.level0Code.GDgrenadesObjects8.length = 0;
gdjs.level0Code.GDgrenadesObjects9.length = 0;
gdjs.level0Code.GDmedkitsObjects1.length = 0;
gdjs.level0Code.GDmedkitsObjects2.length = 0;
gdjs.level0Code.GDmedkitsObjects3.length = 0;
gdjs.level0Code.GDmedkitsObjects4.length = 0;
gdjs.level0Code.GDmedkitsObjects5.length = 0;
gdjs.level0Code.GDmedkitsObjects6.length = 0;
gdjs.level0Code.GDmedkitsObjects7.length = 0;
gdjs.level0Code.GDmedkitsObjects8.length = 0;
gdjs.level0Code.GDmedkitsObjects9.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects1.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects2.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects3.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects4.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects5.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects6.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects7.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects8.length = 0;
gdjs.level0Code.GDHUD_9595nadesObjects9.length = 0;
gdjs.level0Code.GDfloor1Objects1.length = 0;
gdjs.level0Code.GDfloor1Objects2.length = 0;
gdjs.level0Code.GDfloor1Objects3.length = 0;
gdjs.level0Code.GDfloor1Objects4.length = 0;
gdjs.level0Code.GDfloor1Objects5.length = 0;
gdjs.level0Code.GDfloor1Objects6.length = 0;
gdjs.level0Code.GDfloor1Objects7.length = 0;
gdjs.level0Code.GDfloor1Objects8.length = 0;
gdjs.level0Code.GDfloor1Objects9.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects1.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects2.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects3.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects4.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects5.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects6.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects7.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects8.length = 0;
gdjs.level0Code.GDdeath_9595messageObjects9.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects1.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects2.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects3.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects4.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects5.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects6.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects7.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects8.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595buttonObjects9.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects1.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects2.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects3.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects4.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects5.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects6.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects7.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects8.length = 0;
gdjs.level0Code.GDupgrade_9595menuObjects9.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects1.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects2.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects3.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects4.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects5.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects6.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects7.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects8.length = 0;
gdjs.level0Code.GDupgrade_9595menu_9595textObjects9.length = 0;
gdjs.level0Code.GDshadowObjects1.length = 0;
gdjs.level0Code.GDshadowObjects2.length = 0;
gdjs.level0Code.GDshadowObjects3.length = 0;
gdjs.level0Code.GDshadowObjects4.length = 0;
gdjs.level0Code.GDshadowObjects5.length = 0;
gdjs.level0Code.GDshadowObjects6.length = 0;
gdjs.level0Code.GDshadowObjects7.length = 0;
gdjs.level0Code.GDshadowObjects8.length = 0;
gdjs.level0Code.GDshadowObjects9.length = 0;
gdjs.level0Code.GDexit_9595textObjects1.length = 0;
gdjs.level0Code.GDexit_9595textObjects2.length = 0;
gdjs.level0Code.GDexit_9595textObjects3.length = 0;
gdjs.level0Code.GDexit_9595textObjects4.length = 0;
gdjs.level0Code.GDexit_9595textObjects5.length = 0;
gdjs.level0Code.GDexit_9595textObjects6.length = 0;
gdjs.level0Code.GDexit_9595textObjects7.length = 0;
gdjs.level0Code.GDexit_9595textObjects8.length = 0;
gdjs.level0Code.GDexit_9595textObjects9.length = 0;
gdjs.level0Code.GDrageObjects1.length = 0;
gdjs.level0Code.GDrageObjects2.length = 0;
gdjs.level0Code.GDrageObjects3.length = 0;
gdjs.level0Code.GDrageObjects4.length = 0;
gdjs.level0Code.GDrageObjects5.length = 0;
gdjs.level0Code.GDrageObjects6.length = 0;
gdjs.level0Code.GDrageObjects7.length = 0;
gdjs.level0Code.GDrageObjects8.length = 0;
gdjs.level0Code.GDrageObjects9.length = 0;
gdjs.level0Code.GDwallObjects1.length = 0;
gdjs.level0Code.GDwallObjects2.length = 0;
gdjs.level0Code.GDwallObjects3.length = 0;
gdjs.level0Code.GDwallObjects4.length = 0;
gdjs.level0Code.GDwallObjects5.length = 0;
gdjs.level0Code.GDwallObjects6.length = 0;
gdjs.level0Code.GDwallObjects7.length = 0;
gdjs.level0Code.GDwallObjects8.length = 0;
gdjs.level0Code.GDwallObjects9.length = 0;
gdjs.level0Code.GDlevel_9595designObjects1.length = 0;
gdjs.level0Code.GDlevel_9595designObjects2.length = 0;
gdjs.level0Code.GDlevel_9595designObjects3.length = 0;
gdjs.level0Code.GDlevel_9595designObjects4.length = 0;
gdjs.level0Code.GDlevel_9595designObjects5.length = 0;
gdjs.level0Code.GDlevel_9595designObjects6.length = 0;
gdjs.level0Code.GDlevel_9595designObjects7.length = 0;
gdjs.level0Code.GDlevel_9595designObjects8.length = 0;
gdjs.level0Code.GDlevel_9595designObjects9.length = 0;
gdjs.level0Code.GDexplosionObjects1.length = 0;
gdjs.level0Code.GDexplosionObjects2.length = 0;
gdjs.level0Code.GDexplosionObjects3.length = 0;
gdjs.level0Code.GDexplosionObjects4.length = 0;
gdjs.level0Code.GDexplosionObjects5.length = 0;
gdjs.level0Code.GDexplosionObjects6.length = 0;
gdjs.level0Code.GDexplosionObjects7.length = 0;
gdjs.level0Code.GDexplosionObjects8.length = 0;
gdjs.level0Code.GDexplosionObjects9.length = 0;
gdjs.level0Code.GDgrenadeObjects1.length = 0;
gdjs.level0Code.GDgrenadeObjects2.length = 0;
gdjs.level0Code.GDgrenadeObjects3.length = 0;
gdjs.level0Code.GDgrenadeObjects4.length = 0;
gdjs.level0Code.GDgrenadeObjects5.length = 0;
gdjs.level0Code.GDgrenadeObjects6.length = 0;
gdjs.level0Code.GDgrenadeObjects7.length = 0;
gdjs.level0Code.GDgrenadeObjects8.length = 0;
gdjs.level0Code.GDgrenadeObjects9.length = 0;

gdjs.level0Code.eventsList156(runtimeScene);

return;

}

gdjs['level0Code'] = gdjs.level0Code;
